﻿using UnityEngine;
using System.Collections;

public class Trans : MonoBehaviour
{
    private float TransZ_Count = 0;
    private float TransZ_Speed;  //１秒で進む距離
    private float TransZ_FrameSpeed;  //１ﾌﾚｰﾑで進む距離
    private float TransZ_setDistance = 3f;  //移動距離
    private float TransZ_setTime = 1f; //移動時間

    private float TransX_Count = 0;
    private float TransX_Speed;  //１秒で進む距離
    private float TransX_FrameSpeed;  //１ﾌﾚｰﾑで進む距離
    private float TransX_setDistance = 3f;  //移動距離
    private float TransX_setTime = 1f; //移動時間


    // Use this for initialization
    void Start ()
	{
        StartCoroutine("Move");
    }

    // Update is called once per frame
    void Update()
    {
    }

    public IEnumerator Move()
    {
        while (TransZ_Count <= TransZ_setDistance)
        {
            TransZ_Speed = TransZ_setDistance / TransZ_setTime;
            TransZ_FrameSpeed = TransZ_Speed * Time.deltaTime;
            TransZ_Count += TransZ_FrameSpeed;
            this.transform.Translate(0, 0, TransZ_FrameSpeed);
            yield return null;  //処理中断＿1ﾌﾚｰﾑ待って次へ
        }

        yield return new WaitForSeconds(1.0f);//処理中断＿指定秒数待って次へ

        while (TransX_Count <= TransX_setDistance)
        {
            TransX_Speed = TransX_setDistance / TransX_setTime;
            TransX_FrameSpeed = TransX_Speed * Time.deltaTime;
            TransX_Count += TransX_FrameSpeed;
            this.transform.Translate(TransX_FrameSpeed, 0, 0);
            yield return null;  //処理中断＿1ﾌﾚｰﾑ待って次へ
        }

        yield return new WaitForSeconds(1.0f);//処理中断＿指定秒数待って次へ

        while (TransX_Count <= TransX_setDistance)
        {
            TransX_Speed = TransX_setDistance / TransX_setTime;
            TransX_FrameSpeed = TransX_Speed * Time.deltaTime;
            TransX_Count += TransX_FrameSpeed;
            this.transform.Translate(TransX_FrameSpeed, 0, 0);
            yield return null;  //処理中断＿1ﾌﾚｰﾑ待って次へ
        }


    }
}