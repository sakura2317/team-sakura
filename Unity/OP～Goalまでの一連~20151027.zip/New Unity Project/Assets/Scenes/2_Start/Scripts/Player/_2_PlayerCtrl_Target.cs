﻿using UnityEngine;
using System.Collections;

public class _2_PlayerCtrl_Target : MonoBehaviour
{
    private GameObject Player;
    private GameObject Findtarget;
    private GameObject Savetarget;
    private NavMeshAgent NMAgent;

    void Start()
    {
        Player = GameObject.Find("/Player/");
        inActive_NMAComponent();
    }

    void Update()
    {

    }

    public void isTarget()
    {
        Findtarget = GameObject.Find("WrapPoint");
        if (Findtarget != null)
        {
            Active_NMAComponent();
            inActive_TargetObj();
        }
        else if (Findtarget == null)
        {
            Active_TargetObj();
        }
    }

    //inActive →　Active
    public void Active_NMAComponent()
    {
        Player.GetComponent<NavMeshAgent>().enabled = true;
        Findtarget = GameObject.Find("WrapPoint");
        NMAgent = Player.GetComponent<NavMeshAgent>();
        NMAgent.SetDestination((Vector3)Findtarget.transform.position);   //destination=目的地
    }

    //Active →　inActive
    public void inActive_NMAComponent()
    {
        Player.GetComponent<NavMeshAgent>().enabled = false;
    }

    //TargetObj_Active →　inActive
    public void inActive_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            Savetarget = GameObject.Find("WrapPoint");
            Savetarget.SetActive(false);
            inActive_NMAComponent();
        }
    }

    //TargetObj_inActive →　Active
    public void Active_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            //Savetarget = GameObject.Find("GoalPoint");を記述すると、nullなのでエラーとなる
            Savetarget.SetActive(true);
            Active_NMAComponent();
        }
    }

}