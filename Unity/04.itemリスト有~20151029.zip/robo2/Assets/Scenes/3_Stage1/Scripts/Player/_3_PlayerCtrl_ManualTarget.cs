﻿using UnityEngine;
using System.Collections;

public class _3_PlayerCtrl_ManualTarget : MonoBehaviour
{
	private GameObject Player;
	private NavMeshAgent NMAgent;
	private GameObject Findtarget;
	private GameObject Savetarget;

	
	
	void Start()
	{
		Player = GameObject.Find("/Player");
		NMAgent = Player.GetComponent<NavMeshAgent>();
		Findtarget = GameObject.Find("item");
		Savetarget = GameObject.Find("Point");

	}
	
	void Update()
	{

	}

	void OnTriggerEnter(Collider c){
		if (c.gameObject.tag == "itemMark") {

			Savetarget.SetActive(false);
			NMAgent.destination = Findtarget.transform.position;
		}

	}



}