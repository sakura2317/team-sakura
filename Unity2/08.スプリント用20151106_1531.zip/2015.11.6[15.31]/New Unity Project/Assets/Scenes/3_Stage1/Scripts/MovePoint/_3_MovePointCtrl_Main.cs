﻿using UnityEngine;
using System.Collections;

public class _3_MovePointCtrl_Main : MonoBehaviour
{
    private GameObject Obj_Player;
    private GameObject Obj_Door;
    private _3_PlayerCtrl_Main PlayerCtrl;
    private _3_CameraCtrl_Main CameraCtrl;
    private _1_FadeCtrl_Main FCtrl;

    void Start()
    {
        Obj_Player = GameObject.Find("/Player/");
        Obj_Door = GameObject.Find("/Field-Wall/Door/");
        PlayerCtrl = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
        CameraCtrl = Obj_Player.GetComponent<_3_CameraCtrl_Main>();
        FCtrl = GameObject.Find("/_1_Fade/").GetComponent<_1_FadeCtrl_Main>();
    }

    void Update()
    {
        if(Input.GetKey(KeyCode.Return)){
            Application.LoadLevel("4_Stage2");
        }
    }

    public void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>()) //Playerが触れていれば
        {
            //━CameraをOutカメラに強制切り替え━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            CameraCtrl.Comp_CameraIn.enabled = false;
            CameraCtrl.Comp_CameraOut.enabled = true;
            CameraCtrl.Comp_CameraFloor.enabled = false;
            CameraCtrl.Comp_CameraMini.enabled = false;
            //━Search機能_使用不可にする！━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
            PlayerCtrl.Bool_NextStagePoint_Search = false;
            //━Player_position&rotation = MovePoint_position&rotation━━━━━━━━━━━━━━━━━━━━━━
            float PositionX = PlayerCtrl.Obj_NextStagePoint.transform.position.x;
            float PositionY = 1.9f;
            float PositionZ = PlayerCtrl.Obj_NextStagePoint.transform.position.z;
            Obj_Player.transform.position = new Vector3(PositionX, PositionY, PositionZ);
            Obj_Player.transform.rotation = this.transform.rotation;
            //━Door_Open━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (Obj_Door.transform.position.y <= 11.5)
            {
                Obj_Door.transform.Translate(0, 0.05f, 0);
                return;
            }
            //━Door_Open_End → Move(MovePoint & Player)━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            else if (Obj_Door.transform.position.y >= 11.5)
            {
                Obj_Player.transform.Translate(0, 0, Time.deltaTime * 1);
                PlayerCtrl.Obj_NextStagePoint.transform.Translate(0, 0, Time.deltaTime * 1);
            }
            //━SceneChange━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (PlayerCtrl.Obj_NextStagePoint.transform.position.z >= 50 || Input.GetKeyDown(KeyCode.Return))
            {
                if (FCtrl.Int_Fade == 0)
                {
                    FCtrl.FadeOut_Initialize(); //FCtrl.Int_Fade = 0→1→2
                    PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
                }
                if (FCtrl.Int_Fade == 2)
                {
                    Application.LoadLevel("4_Stage2");
                }
            }
        }
    }
}