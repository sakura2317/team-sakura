﻿using UnityEngine;
using System.Collections;

public class _5_PlayerCtrl_Main : MonoBehaviour
{
    //━Player━━━━━━━━━━━━━━━
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.2f;  //Player移動スピード
    //━Move_TriggerPoint━━━━━━━━━
    public GameObject Obj_TriggerPoint;
    //━Search bool━━━━━━━━━━━━
    public bool Search = true;
    private GameObject Main;
    //━Fade━━━━━━━━━━━━━━━━
    private _1_FadeCtrl_Main FCtrl;

    void Start(){
        //━PlayerObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //━GoalPointObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_TriggerPoint = GameObject.Find("/TriggerPoint/");
        //━PlayerObj--Set_NMAComp_Destination━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_PlayerNMAgent.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Main = GameObject.Find("/_3_MainObject/");
        Destroy(Main);
        //━Fadeの初期化━━━━━━━━━━━━━━━━━━
        FCtrl = GameObject.Find("_1_Fade").GetComponent<_1_FadeCtrl_Main>();
        FCtrl.FadeIn_Initialize();
    }

    void Update()
    {
        Action_PositionTranslate_A();   //Playerの移動
        Action_Jump();                  //Playerのジャンプ
        AutoAction_TriggerSearch();     //TriggerPointの探索
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0           , 0, speed       ); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0           , 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed       , 0, 0           ); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0           ); }
    }
    public void Action_PositionTranslate_B()
    {
        float vertical   = Input.GetAxis("Vertical"  );
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up"  ) || Input.GetKey("down" )) { this.transform.Translate(0                   , 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0                 ); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_TriggerPointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_TriggerSearch()
    {
        if (Search == true)
        {
            Vector3 vec = (Vector3)Obj_TriggerPoint.transform.position;
            Comp_PlayerNMAgent.SetDestination(vec);
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}