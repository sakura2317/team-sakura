﻿using UnityEngine;
using System.Collections;

public class _3_UICtrl_Main : MonoBehaviour
{
    private GameObject Obj_UI_Text;
    private Canvas Comp_UITextCanvas;

    void Start()
    {
        Obj_UI_Text = GameObject.Find("/GUI-Text/Canvas/");
        Comp_UITextCanvas = Obj_UI_Text.GetComponent<Canvas>();
    }

    void Update()
    {
        Display();
    }

    public void Display()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (Comp_UITextCanvas.enabled == true) { Comp_UITextCanvas.enabled = false; }
            else if (Comp_UITextCanvas.enabled == false) { Comp_UITextCanvas.enabled = true; }
        }
    }
}