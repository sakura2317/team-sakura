﻿using UnityEngine;
using System.Collections;

public class Debuger : MonoBehaviour
{
    public float timer = 0;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;

    }

    //Test&Debug-Coroutines
    public IEnumerator Coroutines()
    {
        Debug.Log("----- デバッグログ：Coroutines() -----");
        Debug.Log("timer_" + timer);
        for (int i = 0; i < 3; i++)
        {
            yield return new WaitForSeconds(3.0f);
            Debug.Log("timer_" + timer);
        }
    }

    public void Dee()
    {
        Debug.Log("呼び出されました");
        /*
        //オブジェクトの非表示（親子すべて）
        gameObject.SetActiveRecursively(false);
        //オブジェクトの非表示（ひとつだけ）
        Renderer ren = gameObject.GetComponent<Renderer>();
        ren.enabled = false;
        */
    }

}