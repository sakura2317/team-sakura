﻿using UnityEngine;
using System.Collections;

public class _4_StartPointCtrl_Main : MonoBehaviour
{
    private GameObject PointMove;
    private GameObject Player;
    private GameObject Door;
    private GameObject WrapPoint;

    void Start()
    {
        PointMove = GameObject.Find("/StartPoint/");
        Player = GameObject.Find("/Player/");
        Door = GameObject.Find("/Field-Wall/Door/");
        WrapPoint = GameObject.Find("WrapPoint");
        WrapPoint.SetActive(false);
        inActive_NMA();
    }


    void Update()
    {

    }

    public void OnTriggerStay(Collider other)
    {
        Player_ChangeRotate();
        MoveStage();
        MoveDoor();
    }

    public void Player_ChangeRotate()
    {
        Vector3 pos = new Vector3(PointMove.transform.position.x, 1.9f, PointMove.transform.position.z);
        Player.transform.position = pos;
        Player.transform.rotation = PointMove.transform.rotation;
    }

    public void MoveStage()
    {
        if (PointMove.transform.position.z <= -42)
        {
            Player.transform.Translate(0, 0, Time.deltaTime);
            PointMove.transform.Translate(0, 0, Time.deltaTime);
        }
        if (PointMove.transform.position.z >= -42 && Door.transform.position.y <= 4)
        {
            PointMove.SetActive(false);
            WrapPoint.SetActive(true);
            Player.GetComponent<NavMeshAgent>().enabled = true;
            Player.GetComponent<NavMeshAgent>().SetDestination((Vector3)WrapPoint.transform.position);
        }
    }

    public void MoveDoor()
    {
        if (Door.transform.position.y >= 4)
        {
            Door.transform.Translate(0, -0.005f, 0);
        }
    }

    public void inActive_NMA()
    {
        Player.GetComponent<NavMeshAgent>().enabled = false;
    }

}
