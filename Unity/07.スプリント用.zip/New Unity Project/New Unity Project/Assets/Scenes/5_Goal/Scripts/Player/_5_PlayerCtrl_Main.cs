﻿using UnityEngine;
using System.Collections;

public class _5_PlayerCtrl_Main : MonoBehaviour
{
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.5f;          //Player移動スピード
    public GameObject Obj_TriggerPoint;    //リアルタイムnullチェック用
    public GameObject Obj_SaveTriggerPoint;//表示非表示用

    void Start(){
        //━PlayerObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //━GoalPointObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_SaveTriggerPoint = GameObject.Find("/TriggerPoint/");
        Obj_TriggerPoint = Obj_SaveTriggerPoint;
        //━PlayerObj--Set_NMAComp_Destination━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveTriggerPoint.transform.position);
        Debug.Log((Vector3)Obj_SaveTriggerPoint.transform.position);
    }

    void Update()
    {
        Action_PositionTranslate_A();   //Playerの移動
        Action_Jump();                  //Playerのジャンプ
        AutoAction_GoalPointSearch();   //WrapPointの探索
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0           , 0, speed       ); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0           , 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed       , 0, 0           ); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0           ); }
    }
    public void Action_PositionTranslate_B()
    {
        float vertical   = Input.GetAxis("Vertical"  );
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up"  ) || Input.GetKey("down" )) { this.transform.Translate(0                   , 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0                 ); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_TriggerPointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_GoalPointSearch()
    {
        if (Obj_TriggerPoint != null)  //isTriggerPoint
        {
            if (Input.GetKeyDown(KeyCode.P))    //inActive_TriggerPointObj
            {
                Obj_SaveTriggerPoint.SetActive(false);
                Obj_TriggerPoint = null;
                Comp_PlayerNMAgent.enabled = false;
            }
        }
        else if (Obj_TriggerPoint == null)  //isTriggerPoint
        {
            if (Input.GetKeyDown(KeyCode.P))    //Active_TriggerPointObj
            {
                Obj_SaveTriggerPoint.SetActive(true);
                Obj_TriggerPoint = Obj_SaveTriggerPoint;
                Comp_PlayerNMAgent.enabled = true;
                Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveTriggerPoint.transform.position);
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}