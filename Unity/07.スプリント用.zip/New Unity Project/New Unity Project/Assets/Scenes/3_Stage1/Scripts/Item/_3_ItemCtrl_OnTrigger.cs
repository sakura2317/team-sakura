﻿using UnityEngine;
using System.Collections;

public class _3_ItemCtrl_OnTrigger : MonoBehaviour
{
    private GameObject Obj_Player;
    private _3_PlayerCtrl_Main main;

    void Start()
    {
        Obj_Player = GameObject.Find("/Player/");
        main = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
    }

    void Update()
    {

    }

    public void OnTriggerEnter(Collider other)
    {
        if (other == main.Obj_Player.GetComponent<BoxCollider>())
        {
            main.Obj_SaveItem.SetActive(false);
            main.Obj_Item = null;
            //if (main.Obj_GoalPoint == null) { main.Comp_PlayerNMAgent.enabled = false; }
            //if (main.Obj_GoalPoint != null) { main.Comp_PlayerNMAgent.SetDestination((Vector3)main.Obj_SaveGoalPoint.transform.position); }
        }
    }

}