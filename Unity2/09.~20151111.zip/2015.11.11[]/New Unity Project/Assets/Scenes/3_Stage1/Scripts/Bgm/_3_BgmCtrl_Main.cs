﻿using UnityEngine;
using System.Collections;

public class _3_BgmCtrl_Main : MonoBehaviour
{
    public bool DontDestroyEnabled = true;

	void OnEnable ()
	{
        if (DontDestroyEnabled != true) { return; }
            // Sceneを遷移してもオブジェクトが消えないようにする
            DontDestroyOnLoad(this);
    }

    void Update ()
	{
		
	}
}