﻿using UnityEngine;
using System.Collections;

public class RayTest : MonoBehaviour
{
    //public LayerMask mask;
	//Ray ray;
	//private _3_PlayerCtrl_Main main;
	private GameObject HitColliderObj;
	Ray mouseRay;
	RaycastHit hit;
	GameObject cube;
	Camera cam;

    void Start ()
	{
		cube = GameObject.Find ("Item");
		cam = GameObject.Find("/Player/Camera_floor/").GetComponent<Camera>();
    }

    void Update ()
	{
		//ray = new Ray(transform.position, transform.forward);
		mouseRay = cam.ScreenPointToRay(Input.mousePosition);
		Debug.DrawRay(mouseRay.origin, mouseRay.direction*1000, Color.red, 0.1f);

		if (Input.GetMouseButtonUp (0)) {
			searchRoom();
		}
		if(Input.GetKey(KeyCode.U)){
			cube.SetActive (false);
		}

    }

	public void searchRoom(){
		HitColliderObj=null;
		mouseRay = cam.ScreenPointToRay(Input.mousePosition);
		if (Physics.Raycast(mouseRay, out hit, 10000000)) {	//(Raycastの原点の位置,方向,衝突情報,検知距離,レイヤーマスク)
			HitColliderObj = hit.collider.gameObject;
			Debug.Log(hit.collider.gameObject.name);
			//Debug.Log(hit.collider);
			//Debug.Log(hit.collider.gameObject);
			//Debug.Log(hit.collider.gameObject.transform.position);
			Debug.Log(hit.point);

			if(HitColliderObj.name == "Floor"){
				cube.transform.position = hit.point;
				GameObject.Find("Player").GetComponent<NavMeshAgent>().SetDestination((Vector3)cube.transform.position);
				cube.SetActive (true);
				//main.Obj_SaveItem.SetActive(true);

			}
		}
	}
}

//http://megumisoft.hatenablog.com/entry/2015/08/13/172136