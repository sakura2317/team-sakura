﻿using UnityEngine;
using System.Collections;
using System;

public class _5_TriggerPointCtrl_Main : MonoBehaviour
{
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Player;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Door;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Camera;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private int Phase = 1;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    //private _5_PlayerCtrl_Main PlayerCtrl;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    public float timer;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private FadeCtrl FadeCtrl;

    void Start()
    {
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Door = GameObject.Find("/Field-Wall/Door/");
        //━PlayerCtrlのSearch機能をOff━━━━━━━━━━━
        //PlayerCtrl = GameObject.Find("/Player/").GetComponent<_5_PlayerCtrl_Main>();
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Camera = GameObject.Find("/Player/Player_Camera_out/");
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        FadeCtrl = GameObject.Find("/UI/Fade/Panel/").GetComponent<FadeCtrl>();
        

    }

    void Update()
    {
        //timer += Time.deltaTime;
        Action1();
        Action2();
        Action3();
        Action4();
        Action5();
        Action6();
        Action7();
        Action8();


        /*
        //━Action_きょろきょろ━━━━━━━━━━━━━━━━━━━━━
        if (Phase == 2)
        {
            Comp_PlayerNMA.enabled = false;
            if (timer - time2 >= 2f && timer - time2 <= 4f)
            {
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(new Vector3(5,0,5)), 0.1f);
                Debug.Log(Obj_Player.transform.rotation);
            }
            else if (timer - time2 >= 5f && timer - time2 <= 7f)
            {
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(new Vector3(-5, 0, 5)), 0.1f);
                Debug.Log(Obj_Player.transform.rotation);
            }
            else if (timer - time2 >= 7f)
            {
                Phase++;
                time2 = timer;
            }
        }
        //━Action_前へ進む━━━━━━━━━━━━━━━━━━━━━
        else if (Phase == 3)
        {
            if (timer - time2 >= 1f && timer - time2 <= 3f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 5);
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(vec - Obj_Player.transform.position), 0.1f);
            }
            if (timer - time2 >= 1f && timer - time2 <= 8f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 10);
                Obj_Player.transform.position = Vector3.MoveTowards(Obj_Player.transform.position, vec, 0.1f);
            }
            else if (timer - time2 >= 8f)
            {
                Phase++;
                time2 = timer;
            }
        }
        //━Action_上を向く━━━━━━━━━━━━━━━━━━━━━
        else if (Phase == 4)
        {
            if (timer - time2 >= 1f && timer - time2 <= 16f)
            {
                Vector3 vec = new Vector3(Obj_Camera.transform.position.x, Obj_Camera.transform.position.y + 100, Obj_Camera.transform.position.z);
                Obj_Camera.transform.rotation = Quaternion.Slerp(Obj_Camera.transform.rotation, Quaternion.LookRotation(vec - Obj_Camera.transform.position), 0.01f);
            }
            else if (timer - time2 >= 16f)
            {
                Phase++;
                time2 = timer;
            }
        }
        else if (Phase == 5)
        {
            if (FCtrl.Phase == 0)
            {
                FCtrl.FadeOut_Initialization();
                PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
            }
            if (FCtrl.Phase == 2)
            {
                Application.LoadLevel("6_ED");
            }
        }
        */
    }
    //━ドア前まで移動━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action1()
    {
        if (Phase != 1) { return; }
            Debug.Log("act1");
            Obj_Player.transform.position = Vector3.MoveTowards(Obj_Player.transform.position, new Vector3(0, 0, 20), 0.2f);
            //Debug.Log(Obj_Player.transform.position.z);
            if (Math.Round(Obj_Player.transform.position.z) != 20) { return; }
                Phase++;
    }
    //━ドアが開く━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action2()
    {
        if (Phase != 2) { return; }
            Debug.Log("act2");
            if (Obj_Door.transform.position.y <= 11)
            {
                Obj_Door.transform.Translate(0, 0.075f, 0);
                return;
            }
            else { Phase++; }
    }
    //━外へ移動━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action3()
    {
        if (Phase != 3) { return; }
            Debug.Log("act3");
            Obj_Player.transform.position = Vector3.MoveTowards(Obj_Player.transform.position, new Vector3(0, 0, 30), 0.1f);
            if (Math.Round(Obj_Player.transform.position.z) != 30) { return; }
                Phase++;
                timer = 2;//タイマーセット
    }
    //━右を向く━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action4()
    {
        if (Phase != 4) { return; }
        Debug.Log("act4");
        if (timer >= 0) {//タイマー実行
            timer -= Time.deltaTime;
            return;
        }
        Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(new Vector3(5, 0, 5)), 0.075f);
        //Debug.Log(Obj_Player.transform.rotation.y);
        if (Math.Round(Obj_Player.transform.rotation.y*10) != 4) { return; }
            Phase++;
            timer = 2;//タイマーセット
    }
    //━左を向く━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action5()
    {
        if (Phase != 5) { return; }
        Debug.Log("act5");
        if (timer >= 0)
        {//タイマー実行
            timer -= Time.deltaTime;
            return;
        }
        Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(new Vector3(-5, 0, 5)), 0.075f);
        //Debug.Log(Obj_Player.transform.rotation.y);
        if (Math.Round(Obj_Player.transform.rotation.y * 10) != -4) { return; }
        Phase++;
        timer = 2;//タイマーセット
    }
    //━前を向く&前に進む━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action6()
    {
        if (Phase != 6) { return; }
        Debug.Log("act6");
        if (timer >= 0)
        {//タイマー実行
            timer -= Time.deltaTime;
            return;
        }
        Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(new Vector3(0, 0, 0)), 0.1f);
        Obj_Player.transform.position = Vector3.MoveTowards(Obj_Player.transform.position, new Vector3(0, 0, 45), 0.1f);
        if (Math.Round(Obj_Player.transform.position.z) != 45) { return; }
        Phase++;
        timer = 2;//タイマーセット
    }
    //━カメラ上に…━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action7()
    {
        if (Phase != 7) { return; }
        Debug.Log("act7");
        if (timer >= 0)
        {//タイマー実行
            timer -= Time.deltaTime;
            return;
        }
        Obj_Camera.transform.rotation = Quaternion.Slerp(Obj_Camera.transform.rotation, Quaternion.LookRotation(new Vector3(0, 100, 0)), 0.01f);
        Debug.Log(Math.Round(Obj_Camera.transform.rotation.x*10));

        if (Math.Round(Obj_Camera.transform.rotation.x * (-10)) != 7) { return; }
        Phase++;
        timer = 1;//タイマーセット
    }
    public void Action8()
    {
        if (Phase != 8) { return; }
        Debug.Log("act8");
        if (timer >= 0)
        {//タイマー実行
            timer -= Time.deltaTime;
            return;
        }
        FadeCtrl.FadeOut_Initialization();
        Debug.Log("FadeOut");
        Phase = 0;
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}