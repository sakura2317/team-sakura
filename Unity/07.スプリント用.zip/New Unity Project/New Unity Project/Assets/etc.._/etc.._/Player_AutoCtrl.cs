﻿using UnityEngine;
using System.Collections;

public class Player_AutoCtrl : MonoBehaviour
{
    private GameObject PlayerObj;
    private GameObject target;
    private GameObject Findtarget;
    private NavMeshAgent agent;
    private GameObject isGoalPoint;

    void Start ()
	{
        PlayerObj = GameObject.Find("/Player");
        PlayerObj.GetComponent<NavMeshAgent>().enabled = false;
    }

    void Update ()
	{
		
	}

    public void isTarget()
    {
        isGoalPoint = GameObject.Find("GoalPoint");
        if (isGoalPoint == null)
        {

            Findtarget = GameObject.Find("Target");
            if (Findtarget != null)
            {
                target = GameObject.Find("Target");
                GetComponent<NavMeshAgent>().enabled = true;
                NMA_SetDestination();
                ActiveTarget();
            }
            else if (Findtarget == null)
            {
                GetComponent<NavMeshAgent>().enabled = false;
                inActiveTarget();
            }
        }
    }

    public void NMA_SetDestination()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.SetDestination((Vector3)target.transform.position);   //destination=目的地
    }

    public void ActiveTarget()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            if (target.activeSelf == true)
            {
                target.SetActive(false);
            }
        }
    }

    public void inActiveTarget()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            if (target.activeSelf == false)
            {
                target.SetActive(true);
            }
        }
    }

}