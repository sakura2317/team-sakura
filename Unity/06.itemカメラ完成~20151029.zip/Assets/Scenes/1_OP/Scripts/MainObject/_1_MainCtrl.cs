﻿using UnityEngine;
using System.Collections;

public class _1_MainCtrl : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
        //GetComponent<_1_CameraCtrl_Rotate>().RotateA();
        //GetComponent<_1_LightCtrl_Rotate>().RotateA();
        GetComponent<_1_SceneCtrl_Change>().Change();
        
    }
}