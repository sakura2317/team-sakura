﻿using UnityEngine;
using System.Collections;

public class _4_CameraCtrl_Change : MonoBehaviour
{
    private GameObject Camera_in;
    private GameObject Camera_out;
    private GameObject Camera_sky;
    private GameObject Camera_floor;

    private bool In_Enable;
    private bool Out_Enable;
    private bool Sky_Enable;
    private bool Floor_Enable;


    void Start()
    {
        Camera_in = GameObject.Find("/Player/Player_Camera_in");
        Camera_out = GameObject.Find("/Player/Player_Camera_out");
        Camera_sky = GameObject.Find("/MainObject/Camera_sky");
        Camera_floor = GameObject.Find("/Player/Camera_floor");

        Camera_in.GetComponent<Camera>().enabled = false;
        Camera_out.GetComponent<Camera>().enabled = false;
        Camera_sky.GetComponent<Camera>().enabled = false;
        Camera_floor.GetComponent<Camera>().enabled = true;
    }

    void Update()
    {

    }

    public void Change()
    {
        In_Enable = (Camera_in.GetComponent<Camera>().enabled == true);
        Out_Enable = (Camera_out.GetComponent<Camera>().enabled == true);
        Sky_Enable = (Camera_sky.GetComponent<Camera>().enabled == true);
        Floor_Enable = (Camera_floor.GetComponent<Camera>().enabled == true);

        In_Out();
        Sky();
        Floor();
    }

    public void In_Out()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            //Active_Out
            if (In_Enable == true && Out_Enable == false && Sky_Enable == false && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //Active_In
            else if (In_Enable == false && Out_Enable == true && Sky_Enable == false && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = true;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //Active_Out
            else if (In_Enable == false && Out_Enable == false && Sky_Enable == true && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //Active_Out
            else if (In_Enable == false && Out_Enable == false && Sky_Enable == false && Floor_Enable == true)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }
        }
    }

    public void Sky()
    {
        if (Input.GetKeyDown(KeyCode.V))
        {
            //Active_Sky
            if ((In_Enable == true || Out_Enable == true) && Sky_Enable == false && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = true;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //inActive_Out
            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == true && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //Active_Sky
            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == false && Floor_Enable == true)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = true;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }
        }
    }

    public void Floor()
    {
        if (Input.GetKeyDown(KeyCode.B))
        {
            //Active_Floor
            if ((In_Enable == true || Out_Enable == true) && Sky_Enable == false && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = true;
            }

            //Active_Out
            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == false && Floor_Enable == true)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = false;
            }

            //Active_Floor
            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == true && Floor_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = false;
                Camera_floor.GetComponent<Camera>().enabled = true;
            }
        }
    }
}