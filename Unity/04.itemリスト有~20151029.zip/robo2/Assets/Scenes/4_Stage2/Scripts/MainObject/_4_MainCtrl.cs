﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_4_SceneCtrl_Change))]
[RequireComponent(typeof(_4_UICtrl_Active))]
[RequireComponent(typeof(_4_CameraCtrl_Rotate))]
[RequireComponent(typeof(_4_CameraCtrl_Change))]

public class _4_MainCtrl : MonoBehaviour
{
	void Start ()
	{
        //Physics.gravity = new Vector3(0, -8f, 0);
    }

    void Update ()
	{
        GetComponent<_4_CameraCtrl_Change>().Change();
        GetComponent<_4_CameraCtrl_Rotate>().Rotate();
        GetComponent<_4_UICtrl_Active>().Display();
        GetComponent<_4_SceneCtrl_Change>().Change();
        
    }
}