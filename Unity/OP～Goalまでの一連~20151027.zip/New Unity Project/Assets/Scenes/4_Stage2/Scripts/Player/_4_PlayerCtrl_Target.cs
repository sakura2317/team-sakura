﻿using UnityEngine;
using System.Collections;

public class _4_PlayerCtrl_Target : MonoBehaviour
{
    private GameObject PlayerObj;
    private GameObject Findtarget;
    private GameObject Savetarget;
    private NavMeshAgent NMAgent;
	private GameObject PointMove;

    void Start()
    {
        PlayerObj = GameObject.Find("/Player");
        inActive_NMAComponent();
    }

    void Update()
    {

    }

    public void isTarget()
    {
		Findtarget = GameObject.Find ("WrapPoint");

		if (Findtarget != null) {
			Savetarget = GameObject.Find ("WrapPoint");
			Active_NMAComponent ();
			inActive_TargetObj ();
		}
		else if (Findtarget == null) {
			Active_TargetObj ();
		}
    }

    //inActive →　Active
    public void Active_NMAComponent()
    {
        PlayerObj.GetComponent<NavMeshAgent>().enabled = true;
        NMAgent = PlayerObj.GetComponent<NavMeshAgent>();
		NMAgent.SetDestination((Vector3)Savetarget.transform.position);   //destination=目的地
    }

    //Active →　inActive
    public void inActive_NMAComponent()
    {
        PlayerObj.GetComponent<NavMeshAgent>().enabled = false;
    }

    //TargetObj_Active →　inActive
    public void inActive_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            Savetarget.SetActive(false);
            inActive_NMAComponent();
        }
    }

    //TargetObj_inActive →　Active
    public void Active_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            Savetarget.SetActive(true);
            Active_NMAComponent();
        }
    }

}