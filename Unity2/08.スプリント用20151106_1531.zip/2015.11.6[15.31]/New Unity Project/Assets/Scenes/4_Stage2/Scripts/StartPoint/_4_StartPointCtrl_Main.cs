﻿using UnityEngine;
using System.Collections;

public class _4_StartPointCtrl_Main : MonoBehaviour
{
    private GameObject Obj_Player;
    private GameObject Obj_Door;
    private GameObject Obj_StartPoint;
    private _4_PlayerCtrl_Main PlayerCtrl;
    private _4_CameraCtrl_Main CameraCtrl;

    void Start()
    {
        Obj_Player = GameObject.Find("/Player/");
        Obj_Door = GameObject.Find("/Field-Wall/Door/");
        Obj_StartPoint = GameObject.Find("StartPoint");
        PlayerCtrl = Obj_Player.GetComponent<_4_PlayerCtrl_Main>();
        CameraCtrl = Obj_Player.GetComponent<_4_CameraCtrl_Main>();
    }

    void Update()
    {

    }

    public void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>()) //Playerが触れていれば
        {
            PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
            //━Player_position&rotation = MovePoint_position&rotation━━━━━━━━━━━━━━━━━━━━━━
            float PositionX = Obj_StartPoint.transform.position.x;
            float PositionY = 1.9f;
            float PositionZ = Obj_StartPoint.transform.position.z;
            Obj_Player.transform.position = new Vector3(PositionX, PositionY, PositionZ);
            Obj_Player.transform.rotation = this.transform.rotation;
            //━Move_Stage━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (Obj_StartPoint.transform.position.z <= -42)
            {
                Obj_Player.transform.Translate(0, 0, Time.deltaTime * 3);
                Obj_StartPoint.transform.Translate(0, 0, Time.deltaTime * 3);
                return;
            }
            else if (CameraCtrl.Comp_CameraFloor.enabled == false)
            {
                //━CameraをFloorカメラに強制切り替え━━━
                CameraCtrl.Comp_CameraIn.enabled = false;
                CameraCtrl.Comp_CameraOut.enabled = false;
                CameraCtrl.Comp_CameraFloor.enabled = true;
                CameraCtrl.Comp_CameraMini.enabled = true;
            }
            //━Close_Door━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (Obj_Door.transform.position.y >= 4)
            {
                Obj_Door.transform.Translate(0, -0.05f, 0);
            }
            else if (Obj_StartPoint.transform.position.z >= -42 && Obj_Door.transform.position.y <= 4)
            {
                //Obj_StartPointの削除
                Obj_StartPoint.SetActive(false);
                //Obj_NextStagePointの表示 & NMAgent_Set
                PlayerCtrl.Obj_NextStagePoint.SetActive(true);
                Obj_Player.GetComponent<NavMeshAgent>().enabled = true;
                Obj_Player.GetComponent<NavMeshAgent>().SetDestination((Vector3)PlayerCtrl.Obj_NextStagePoint.transform.position);
                //━Search機能_使用可能にする！━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                PlayerCtrl.Bool_NextStagePoint_Search = true;
            }
        }
    }
}
