﻿using UnityEngine;
using System.Collections;

public class _2_UICtrl_Active : MonoBehaviour
{
    private GameObject GUI_Text;
    void Start()
    {
        GUI_Text = GameObject.Find("/GUI-Text/Canvas");
    }

    void Update()
    {

    }

    public void Display()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (GUI_Text.GetComponent<Canvas>().enabled == true)
            {
                GUI_Text.GetComponent<Canvas>().enabled = false;
            }
            else if (GUI_Text.GetComponent<Canvas>().enabled == false)
            {
                GUI_Text.GetComponent<Canvas>().enabled = true;
            }
        }
    }
}