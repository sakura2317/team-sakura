﻿using UnityEngine;
using System.Collections;

public class UI_Menu : MonoBehaviour
{
    private GameObject UI;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private _1_FadeCtrl_Main FCtrl;

    // Use this for initialization
    void Start ()
	{
        UI = GameObject.Find("/UI_Menu/");
        Destroy(UI);
        //━Fadeの初期化━━━━━━━━━━━━━━━━━━
        FCtrl = GameObject.Find("_1_Fade").GetComponent<_1_FadeCtrl_Main>();
        FCtrl.FadeIn_Initialize();
    }

    // Update is called once per frame
    void Update ()
	{
		
	}
}