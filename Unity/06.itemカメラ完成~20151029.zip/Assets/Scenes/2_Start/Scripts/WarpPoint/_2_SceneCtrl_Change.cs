﻿using UnityEngine;
using System.Collections;

public class _2_SceneCtrl_Change : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
		
	}

    public void Change()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
			Application.LoadLevel ("3_Stage1");
			//Application.LoadLevelAdditive ("3_Stage1");
        }
    }

	public void OnTriggerEnter(Collider other){
		Application.LoadLevel ("3_Stage1");
		//Application.LoadLevelAdditive ("3_Stage1");
	}

}