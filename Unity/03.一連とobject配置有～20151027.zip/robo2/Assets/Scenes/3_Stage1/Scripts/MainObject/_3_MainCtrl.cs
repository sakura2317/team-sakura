﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_3_SceneCtrl_Change))]
[RequireComponent(typeof(_3_UICtrl_Active))]
[RequireComponent(typeof(_3_CameraCtrl_Rotate))]
[RequireComponent(typeof(_3_CameraCtrl_Change))]

public class _3_MainCtrl : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
        //Physics.gravity = new Vector3(0, -8f, 0);
    }

    // Update is called once per frame
    void Update ()
	{
        GetComponent<_3_CameraCtrl_Change>().Change();
        GetComponent<_3_CameraCtrl_Rotate>().Rotate();
        GetComponent<_3_UICtrl_Active>().Display();

        //追尾の優先順位はここでの順番
        //GetComponent<_3_PlayerCtrl_Target>().isTarget();       //優先度：低い
        //GetComponent<_3_PlayerCtrl_SubTarget>().isTarget();    //優先度：高い

        GetComponent<_3_SceneCtrl_Change>().Change();
        
    }
}