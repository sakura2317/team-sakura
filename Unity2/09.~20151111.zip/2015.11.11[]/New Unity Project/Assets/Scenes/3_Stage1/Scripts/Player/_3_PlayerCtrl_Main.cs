﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class _3_PlayerCtrl_Main : MonoBehaviour
{
    //━Player━━━━━━━━━━━━━━━
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.6f;  //Player移動スピード
    //━NextStagePoint━━━━━━━━━━
    public bool Bool_NextStagePoint_Search; //NextStagePointSearchチェック用
    public GameObject Obj_NextStagePoint;
    //━Item━━━━━━━━━━━━━━━━
    public bool Bool_Item_Search; //ItemSearchチェック用
    public GameObject Obj_Item;
    //━Ray━━━━━━━━━━━━━━━━
    private Camera Comp_Camera;
    private Ray Ray_mouse;
    private RaycastHit RaycastHit_Info;
    //━Fade━━━━━━━━━━━━━━━━
    private FadeCtrl FadeCtrl;
    //━Door━━━━━━━━━━━━━━━━━━━━━━
    public GameObject[] door1;
    public GameObject[] door2;
    public GameObject[] door3;
    //━Item_peice━━━━━━━━━━━━━
    public int Count = 0; //スコア計算用変数
    public int CountCheck = 2; //スコア計算用変数
    public float f = 0;
    public Text Text; //Text用変数
    public GameObject prefab;
    //━SE━━━━━━━━━━━━━
    private AudioSource Comp_AudioSource;
    public AudioClip SE_Item;                       // 効果音の格納用。インスペクタで。
    public bool Bool_SE_Item;
    public AudioClip SE_Item_piece;                 // 効果音の格納用。インスペクタで。
    public bool Bool_SE_Item_piece;
    public AudioClip SE_Door;                       // 効果音の格納用。インスペクタで。
    public bool Bool_SE_Door;
    public AudioClip SE_NextStageDoor;                       // 効果音の格納用。インスペクタで。
    public bool Bool_SE_NextStageDoor;

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EveryTime__[Obj_setActive==true && Comp_enabled==true]
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void OnEnable()
    {
        //━Player━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //━NextStagePoint━━━━━━━━━━━━━━━━
        Obj_NextStagePoint = GameObject.Find("/Action/MovePoint/");    //SetDestinationがあるためPlayerより先に記述！
        Bool_NextStagePoint_Search = false;
        Comp_PlayerNMAgent.enabled = true;
        //Comp_PlayerNMAgent.SetDestination((Vector3)Obj_NextStagePoint.transform.position);
        //━Item━━━━━━━━━━━━━━━━━━━━━━
        Obj_Item = GameObject.Find("/Item/");
        Obj_Item.SetActive(false);
        Bool_Item_Search = true;
        Comp_AudioSource = GetComponent<AudioSource>();
        //━Ray━━━━━━━━━━━━━━━━━━━━━━━
        Comp_Camera = GameObject.Find("/Player/Camera_floor/").GetComponent<Camera>();
        //━Fadeの初期化━━━━━━━━━━━━━━━━━━
        FadeCtrl = GameObject.Find("/UI/Fade/Panel/").GetComponent<FadeCtrl>();
        FadeCtrl.FadeIn_Initialization();
        //━Door━━━━━━━━━━━━━━━━━━━━━━
        door1 = GameObject.FindGameObjectsWithTag("Door1");
        door2 = GameObject.FindGameObjectsWithTag("Door2");
        door3 = GameObject.FindGameObjectsWithTag("Door3");
        //━Item_peice━━━━━━━━━━━━━
        Instantiate(prefab, new Vector3(-24, 0, -30), Quaternion.identity);
        Instantiate(prefab, new Vector3(-44, 0, -26), Quaternion.identity);
        //Instantiate(prefab, new Vector3(-30, 0, -40), Quaternion.identity);
        Text = GameObject.Find("/UI/ItemCount/Text/").GetComponent<Text>();
        Text.text = "Item: " + Count;
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // Update
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void Update()
    {
        Action_PositionTranslate_A();       //Playerの移動
        //Action_Jump();                      //Playerのジャンプ
        AutoAction_NextStagePointSearch();  //NextStagePointの探索
        AutoAction_ItemSearch();            //Itemの探索
        Sound_Item();
        Sound_Item_piece();
        Sound_Door();
        Sound_NextStageDoor();
        Door1Open();
        Door2Open();
        Door3Open();
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0, 0, speed); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0, 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed, 0, 0); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0); }
    }/*
    public void Action_PositionTranslate_B()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up") || Input.GetKey("down")) { this.transform.Translate(0, 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0); }
    }*/
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_NextStagePointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_NextStagePointSearch()
    {
        if (Bool_NextStagePoint_Search != true) { return; }
            Vector3 vec = (Vector3)Obj_NextStagePoint.transform.position;
            Comp_PlayerNMAgent.SetDestination(vec);
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_ItemSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_ItemSearch()
    {
        if (Bool_Item_Search != true) { return; }
        if (Input.GetMouseButtonUp(0) != true) { return; }
            Bool_NextStagePoint_Search = false;
            //━Rayを作成(Mouse位置を原点とする)━━━
            Ray_mouse = Comp_Camera.ScreenPointToRay(Input.mousePosition);
            Debug.DrawRay(Ray_mouse.origin, Ray_mouse.direction * 1000, Color.red, 0.1f);//SceneViewでRayを表示
            //━RayとColliderの衝突検出━━━━━━━━
            Physics.Raycast(Ray_mouse, out RaycastHit_Info, 10000000);
            if (RaycastHit_Info.collider.gameObject.name != "Floor") { return; }
                //━Rayがhitした位置にItemを移動・表示━━━━━
                Obj_Item.transform.position = RaycastHit_Info.point;
                Obj_Item.SetActive(true);
                //━NMAgent_SetDestination━━━━━━━━
                Comp_PlayerNMAgent.enabled = true;
                Comp_PlayerNMAgent.SetDestination((Vector3)Obj_Item.transform.position);
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // SE
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Sound_Item()
    {
        if(Bool_SE_Item != true) { return; }
            Comp_AudioSource.PlayOneShot(SE_Item);
            Bool_SE_Item = false;
    }
    public void Sound_Item_piece()
    {
        if (Bool_SE_Item_piece != true) { return; }
            Comp_AudioSource.PlayOneShot(SE_Item_piece);
            Bool_SE_Item_piece = false;
    }
    public void Sound_Door()
    {
        if (Bool_SE_Door != true) { return; }
            Comp_AudioSource.PlayOneShot(SE_Door);
            Bool_SE_Door = false;
    }
    public void Sound_NextStageDoor()
    {
        if(Bool_SE_NextStageDoor != true) { return; }
            Comp_AudioSource.PlayOneShot(SE_NextStageDoor);
            Bool_SE_NextStageDoor = false;
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Door1Open()
    {
        if (Count != 2) { return; }
        if (Count != CountCheck) { return; }
        if (f == 0) { Bool_SE_Door = true; }
            if (f <= (7f*door1.Length))
                {
                Bool_Item_Search = false;
                for (int i = 0; i < door1.Length; i++)
                {
                    f += 0.3f;
                    door1[i].transform.Translate(-0.3f, 0, 0);
                }
            }
            else if (f >= (7f * door1.Length))
            {
                Bool_Item_Search = true;
                CountCheck = 5;
                f = 0;
                Instantiate(prefab, new Vector3(-25, 0, 0), Quaternion.identity);
                Instantiate(prefab, new Vector3(-0, 0, -26), Quaternion.identity);
                Instantiate(prefab, new Vector3(8.5f, 0, -21), Quaternion.identity);
        }
    }
    public void Door2Open()
    {
        if (Count != 5) { return; }
        if (Count != CountCheck) { return; }
        if (f == 0) { Bool_SE_Door = true; }
            if (f <= (7f * door2.Length))
                {
                Bool_Item_Search = false;
                for (int i = 0; i < door2.Length; i++)
                {
                    f += 0.3f;
                    door2[i].transform.Translate(-0.3f, 0, 0);
                }
            }
            else if (f >= (7f * door2.Length))
            {
                Bool_Item_Search = true;
                CountCheck = 9;
                f = 0;
                Instantiate(prefab, new Vector3(25, 0, 0), Quaternion.identity);
                Instantiate(prefab, new Vector3(0, 0, 25), Quaternion.identity);
                Instantiate(prefab, new Vector3(25, 0, -45), Quaternion.identity);
                Instantiate(prefab, new Vector3(-45, 0, 25), Quaternion.identity);
        }
    }
    public void Door3Open()
    {
        if (Count != 9) { return; }
        if (Count != CountCheck) { return; }
        if (f == 0) { Bool_SE_Door = true; }
            if (f <= (7f * door3.Length))
                {
                Bool_Item_Search = false;
                for (int i = 0; i < door3.Length; i++)
                {
                    f += 0.3f;
                    door3[i].transform.Translate(-0.3f, 0, 0);
                }
            }
            else if (f >= (7f * door3.Length))
            {
                Comp_PlayerNMAgent.enabled = true;
                Bool_NextStagePoint_Search = true;
            }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━



    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}