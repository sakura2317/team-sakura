﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ImageCtrl : MonoBehaviour
{
    public GameObject Obj_Canvas;
    public GameObject Obj_Panel;
    public GameObject Obj_Image1;
    public GameObject Obj_Image2;
    public GameObject Obj_Image3;
    public GameObject Obj_Image4;
    /*
    public RectTransform Rect_Canvas;
    public RectTransform Rect_Panel;
    public RectTransform Rect_Image1;
    public RectTransform Rect_Image2;
    */
    public Image Image_Image1;
    public Image Image_Image2;
    public Image Image_Image3;
    public Image Image_Image4;
    //━Section管理━━━━━━━━━━━━━━━
    public int Phase = 1;
    public float WaitTimer;
    //━Fade1━━━━━━━━━━━━━━━
    public float FadeTime1 = 1f;
    public float FadeInTimer1;
    public float FadeOutTimer1;
    public Color FadeInCol1;
    public Color FadeOutCol1;
    //━Fade2━━━━━━━━━━━━━━━
    public float FadeTime2 = 1.5f;
    public float FadeInTimer2;
    public float FadeOutTimer2;
    public Color FadeInCol2;
    public Color FadeOutCol2;

    void Start()
    {
        /*━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Canvas / Comp_Canvas / Render Mode = World Space
        Obj_Canvas / Comp_Rect Transform 
            / Pos = 0 , Width = 800 , Height = 500 , Anchors = 0.5 , Pivot = 0.5 */
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Canvas = GameObject.Find("Canvas");
        Obj_Panel = GameObject.Find("Canvas/Panel");
        Obj_Image1 = GameObject.Find("Canvas/Image1");
        Obj_Image2 = GameObject.Find("Canvas/Image2");
        Obj_Image3 = GameObject.Find("Canvas/Image3");
        Obj_Image4 = GameObject.Find("Canvas/Image4");
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Image_Image1 = Obj_Image1.GetComponent<Image>();
        Image_Image2 = Obj_Image2.GetComponent<Image>();
        Image_Image3 = Obj_Image3.GetComponent<Image>();
        Image_Image4 = Obj_Image4.GetComponent<Image>();
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Canvas.transform.position = new Vector3(0, 0, 0);
        Obj_Image1.transform.position = new Vector3(-60, 0, 0);
        Obj_Image2.transform.position = new Vector3(-120, 0, 0);
        Obj_Image3.transform.position = new Vector3(300, 150, 0);
        Obj_Image4.transform.position = new Vector3(-300, 150, 0);
        WaitTimer = 2;
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        /*
        Rect_Canvas = Obj_Canvas.GetComponent<RectTransform>();
        Rect_Panel = Obj_Panel.GetComponent<RectTransform>();
        Rect_Image1 = Obj_Image1.GetComponent<RectTransform>();
        Rect_Image2 = Obj_Image2.GetComponent<RectTransform>();
        Debug.Log("━Compornent(RectTransform)━━━━━━━━━━━━");
        Debug.Log(Rect_Canvas);
        Debug.Log("　　　┣━size     : " + Rect_Canvas.rect.size);
        Debug.Log("　　　┣━width    : " + Rect_Canvas.rect.width);
        Debug.Log("　　　┣━height   : " + Rect_Canvas.rect.height);
        Debug.Log("　　　┣━position : " + Rect_Canvas.rect.position + "左下の座標？");
        Debug.Log("　　　┣━position.x : " + Rect_Canvas.rect.position.x);
        Debug.Log("　　　┣━position.y : " + Rect_Canvas.rect.position.y);
        Debug.Log("　　　┣━min      : " + Rect_Canvas.rect.min + "左下の座標");
        Debug.Log("　　　┣━max      : " + Rect_Canvas.rect.max + "右上の座標");
        Debug.Log("　　　┣━xMin     : " + Rect_Canvas.rect.xMin);
        Debug.Log("　　　┣━xMax     : " + Rect_Canvas.rect.xMax);
        Debug.Log(Rect_Panel);
        Debug.Log("　　　┣━width  : " + Rect_Panel.rect.width);
        Debug.Log("　　　┣━height : " + Rect_Panel.rect.height);
        Debug.Log(Rect_Image1);
        Debug.Log("　　　┣━width  : " + Rect_Image1.rect.width);
        Debug.Log("　　　┣━height : " + Rect_Image1.rect.height);
        Debug.Log(Rect_Image2);
        Debug.Log("　　　┣━width  : " + Rect_Image2.rect.width);
        Debug.Log("　　　┣━height : " + Rect_Image2.rect.height);
        */
    }

    void Update()
    {
        Action1();
        Action2();
        Action3();
        Action4();
        Action5();
    }

    public void Action1()
    {
        if (Phase != 1) { return; }
        Obj_Image1.transform.position = new Vector3(-60, 0, 0);     //FadeInするObjectの位置を指定
        Obj_Image3.transform.position = new Vector3(300, 150, 0);
        if (WaitTimer > 0){ WaitTimer -= Time.deltaTime; return; }  //WaitTimerの実行
        Fade1(Image_Image1 , Image_Image2 , 2);                     //Fadeの実行
        Fade2(Image_Image3, Image_Image4);
    }
    public void Action2()
    {
        if (Phase != 2) { return; }
        Obj_Image2.transform.position = new Vector3(0, 0, 0);
        Obj_Image4.transform.position = new Vector3(300, -150, 0);
        if (WaitTimer > 0) { WaitTimer -= Time.deltaTime; return; }
        Fade1(Image_Image2, Image_Image1, 2);
        Fade2(Image_Image4, Image_Image3);
    }
    public void Action3()
    {
        if (Phase != 3) { return; }
        Obj_Image1.transform.position = new Vector3(60, 0, 0);
        Obj_Image3.transform.position = new Vector3(-300, -150, 0);
        if (WaitTimer > 0) { WaitTimer -= Time.deltaTime; return; }
        Fade1(Image_Image1, Image_Image2, 2);
        Fade2(Image_Image3, Image_Image4);
    }
    public void Action4()
    {
        if (Phase != 4) { return; }
        Obj_Image2.transform.position = new Vector3(120, 0, 0);
        Obj_Image4.transform.position = new Vector3(-300, 150, 0);
        if (WaitTimer > 0) { WaitTimer -= Time.deltaTime; return; }
        Fade1(Image_Image2, Image_Image1, 2);
        Fade2(Image_Image4, Image_Image3);
    }
    public void Action5()
    {
        if (Phase != 5) { return; }
        Phase = 1;
    }
    public void Fade1(Image FadeIn, Image FadeOut, float t)
    {
        //━初期化━━━━━━━━━━━━━
        if (FadeIn.color.a <= 0)
        {
            FadeInTimer1 = 0;
            FadeOutTimer1 = 1;
            FadeInCol1 = FadeIn.color;
            FadeOutCol1 = FadeOut.color;
        }
        //━Fadeの実行━━━━━━━━━━━━━
        FadeInTimer1 += Time.deltaTime;
        FadeOutTimer1 -= Time.deltaTime;
        FadeInCol1.a = FadeInTimer1 / FadeTime1;
        FadeOutCol1.a = FadeOutTimer1 / FadeTime1;
        FadeIn.color = FadeInCol1;
        FadeOut.color = FadeOutCol1;
        //━Fadeの終了判定━━━━━━━━━━━
        if (FadeIn.color.a < 1) { return; }
        WaitTimer = t;
        Phase++;
    }
    public void Fade2(Image FadeIn, Image FadeOut)
    {
        //━初期化━━━━━━━━━━━━━
        if (FadeIn.color.a <= 0)
        {
            FadeInTimer2 = 0;
            FadeOutTimer2 = 1;
            FadeInCol2 = FadeIn.color;
            FadeOutCol2 = FadeOut.color;
        }
        //━Fadeの実行━━━━━━━━━━━━━
        FadeInTimer2 += Time.deltaTime;
        FadeOutTimer2 -= Time.deltaTime;
        FadeInCol2.a = FadeInTimer2 / FadeTime2;
        FadeOutCol2.a = FadeOutTimer2 / FadeTime2;
        FadeIn.color = FadeInCol2;
        FadeOut.color = FadeOutCol2;
    }
}