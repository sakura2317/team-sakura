﻿using UnityEngine;
using System.Collections;

public class _4_SceneCtrl_Change : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
        Change();
	}

    public void Change()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
			Application.LoadLevel ("5_Goal");
			//Application.LoadLevelAdditive ("3_Stage1");
        }
    }

	public void OnTriggerEnter(Collider other){
		Application.LoadLevel ("5_Goal");
		//Application.LoadLevelAdditive ("3_Stage1");
	}

}