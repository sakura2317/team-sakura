﻿using UnityEngine;
using System.Collections;

public class _5_TriggerPointCtrl_Main : MonoBehaviour
{
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Player;
    private NavMeshAgent Comp_PlayerNMA;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_TriggerPoint;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Door;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private GameObject Obj_Camera;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private int Phase = 0;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private _5_PlayerCtrl_Main PlayerCtrl;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private float timer;
    //private float time1;
    private float time2;
    //━━━━━━━━━━━━━━━━━━━━━━━━━━
    private _1_FadeCtrl_Main FCtrl;

    void Start()
    {
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMA = Obj_Player.GetComponent<NavMeshAgent>();
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_TriggerPoint = GameObject.Find("/TriggerPoint/");
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Door = GameObject.Find("/Field-Wall/Door/");
        //━PlayerCtrlのSearch機能をOff━━━━━━━━━━━
        PlayerCtrl = GameObject.Find("/Player/").GetComponent<_5_PlayerCtrl_Main>();
        PlayerCtrl.Search = false;
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Camera = GameObject.Find("/Player/Player_Camera_out/");
        //━━━━━━━━━━━━━━━━━━━━━━━━━━
        FCtrl = GameObject.Find("/_1_Fade/").GetComponent<_1_FadeCtrl_Main>();
    }

    void Update()
    {
        SceneChange();
        timer += Time.deltaTime;
        Debug.Log(Phase);
        //━Action_きょろきょろ━━━━━━━━━━━━━━━━━━━━━
        if (Phase == 2)
        {
            //Debug.Log("time2:::" + time2 + "_____差分:::" + (timer - time2));
            Comp_PlayerNMA.enabled = false;
            if (timer - time2 >= 2f && timer - time2 <= 4f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x + 5, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 5);
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(vec - Obj_Player.transform.position), 0.1f);
            }
            else if (timer - time2 >= 5f && timer - time2 <= 7f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x - 5, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 5);
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(vec - Obj_Player.transform.position), 0.1f);
            }
            else if (timer - time2 >= 7f)
            {
                Phase++;
                time2 = timer;
            }
        }
        //━Action_前へ進む━━━━━━━━━━━━━━━━━━━━━
        else if (Phase == 3)
        {
            if (timer - time2 >= 1f && timer - time2 <= 3f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 5);
                Obj_Player.transform.rotation = Quaternion.Slerp(Obj_Player.transform.rotation, Quaternion.LookRotation(vec - Obj_Player.transform.position), 0.1f);
            }
            if (timer - time2 >= 1f && timer - time2 <= 8f)
            {
                Vector3 vec = new Vector3(Obj_Player.transform.position.x, Obj_Player.transform.position.y, Obj_Player.transform.position.z + 10);
                Obj_Player.transform.position = Vector3.MoveTowards(Obj_Player.transform.position, vec, 0.1f);
            }
            else if (timer - time2 >= 8f)
            {
                Phase++;
                time2 = timer;
            }
        }
        //━Action_上を向く━━━━━━━━━━━━━━━━━━━━━
        else if (Phase == 4)
        {
            if (timer - time2 >= 1f && timer - time2 <= 10f)
            {
                Vector3 vec = new Vector3(Obj_Camera.transform.position.x, Obj_Camera.transform.position.y + 100, Obj_Camera.transform.position.z);
                Obj_Camera.transform.rotation = Quaternion.Slerp(Obj_Camera.transform.rotation, Quaternion.LookRotation(vec - Obj_Camera.transform.position), 0.01f);
            }
            else if (timer - time2 >= 10f)
            {
                Phase++;
                time2 = timer;
            }
        }
        else if (Phase == 5)
        {
            if (FCtrl.Int_Fade == 0)
            {
                FCtrl.FadeOut_Initialize();
                PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
            }
            if (FCtrl.Int_Fade == 2)
            {
                Application.LoadLevel("6_ED");
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // Action_DoorOpen & ChangeTriggerPoint
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void OnTriggerEnter(Collider other)
    {
        Phase++;
        time2 = timer;
    }

    public void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>())
        {
            //━Doorあける→次のポイントへ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            if (Phase == 1)
            {
                //Comp_NMA をOffにする
                Comp_PlayerNMA.enabled = false;
                //Playerの位置・回転を固定
                Vector3 pos = new Vector3(Obj_TriggerPoint.transform.position.x, 1.25f, Obj_TriggerPoint.transform.position.z);
                Obj_Player.transform.position = pos;
                Obj_Player.transform.rotation = Obj_TriggerPoint.transform.rotation;
                //━OpenDoor━━━━━━━━━━━━━━━
                if (Obj_Door.transform.position.y <= 11.5)
                {
                    Obj_Door.transform.Translate(0, 0.05f, 0);
                    return;
                }
                //━NMAの次の目的地を設定━━━━━━━━━
                else if (Obj_Door.transform.position.y >= 11.5)
                {
                    Obj_TriggerPoint.transform.position = new Vector3(0, 1.25f, 35);
                    Comp_PlayerNMA.enabled = true;
                    Comp_PlayerNMA.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
                }
            }
        }
    }











    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // SceneChangeCtrl
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void SceneChange()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("6_ED");
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}