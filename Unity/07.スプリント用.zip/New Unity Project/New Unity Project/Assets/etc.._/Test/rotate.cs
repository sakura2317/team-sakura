﻿using UnityEngine;
using System.Collections;

public class rotate : MonoBehaviour
{
    float f = 0;
    GameObject A;
    Vector3 vec;

    // Use this for initialization
    void Start ()
	{
        A = GameObject.Find("A");
        Debug.Log(vec);
	}
	
	// Update is called once per frame
	void Update ()
	{
        f += 1;

        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //━全ての軸の角度をfloatで指定して回転_オイラー角━━━━━━━━━━━━━━━━━━━
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //this.transform.Rotate(0, 1, 0);
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //━ローカル座標（親オブジェクトの座標を原点）での回転 ━━━━━━━━━━━━━━━━━
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //this.transform.rotation = Quaternion.AngleAxis(f, Vector3.up);//現在のｸｫｰﾀﾆｵﾝに指定値を合成
        //this.transform.rotation = Quaternion.AngleAxis(f, Vector3(0,1,0));//上と同じ（変化量,軸）
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //━_オイラー角━━━━━━━━━━━━━
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //this.transform.eulerAngles = new Vector3(0,f,0);
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        //━Quaternion.Slerp━
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (Input.GetMouseButton(0))
        {
            vec = Input.mousePosition;
            Debug.Log(Input.mousePosition);
            this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.LookRotation(vec - this.transform.position), 0.1f);
        }
        //fromを0.0、toを1.0として捉え、その間にあるt(0.0～1.0)のクォータニオンを求めるのがQuaternion.Slerp()になります。 
        //tの値を小さくすれば、fromがtoの方向へ少しずつ近づくようになります。(t = 1.0ならLookAt() / LookRotation()と同じ)
        //Quaternion.LookRotation(VectorA - VectorB);____VectorBの地点から見て、VectorAの方向を取得することが出来ます。 

        //Debug.Log("rotation" + this.transform.rotation);
        //Debug.Log("eulerAngles"+this.transform.eulerAngles);
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    }
}

/*
transform.eulerAngles・・・・・オイラー角としての回転値
transform.rotation・・・・・・・ローカル座標での回転値
transform.Rotate・・・・・・・・オブジェクトを相対的に回転させます
━━transform.Rotate━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
回転を相対的にアニメートさせたいなら、Rotateを使えと。
// ローカルX軸で１秒に１度回転　＿（「軸」と「回転値」を指定）
transform.Rotate(Time.deltaTime, 0, 0);             //(x,y,z)＿全ての軸の角度をfloatで指定して回転
transform.Rotate(Vector3.right * Time.deltaTime);   //Vector3.right=(1,0,0)＿オイラー角を指定して回転
transform.Rotate(Vector3.right, Time.deltaTime);    //軸をVector3、角度をfloatで指定して回転

//ワールドで回したいならSpace.Worldを入れとく
transform.Rotate(Time.deltaTime, 0, 0, Space.World);
    ┣Space.World　はワールド座標（全ての空間の座標を原点）
    ┣Space.Self　はローカル座標（親オブジェクトの座標を原点）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
オイラー角での変換はどの軸に何度回転させるというx軸, y軸, z軸それぞれに何度という3つの情報だけで変換が表せる。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        if (this.transform.rotation != Quaternion.AngleAxis(30, Vector3.up))
        {
            this.transform.Rotate(0, -1, 0);
        }
*/
