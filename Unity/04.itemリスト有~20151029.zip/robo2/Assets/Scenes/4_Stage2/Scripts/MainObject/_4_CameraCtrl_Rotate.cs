﻿using UnityEngine;
using System.Collections;

public class _4_CameraCtrl_Rotate : MonoBehaviour
{
    private GameObject Player;
    private GameObject Camera_in;
    private GameObject Camera_out;
    private GameObject Camera_sky;
    private GameObject Camera_floor;
    private bool In_Enable;
    private bool Out_Enable;
    private bool Sky_Enable;
    private bool Floor_Enable;

    void Start()
    {
        Player = GameObject.Find("Player");
        Camera_in = GameObject.Find("/Player/Player_Camera_in");
        Camera_out = GameObject.Find("/Player/Player_Camera_out");
        Camera_sky = GameObject.Find("/MainObject/Camera_sky");
        Camera_floor = GameObject.Find("/Player/Camera_floor");
    }

    void Update()
    {

    }
    public void Rotate()
    {
        In_Enable = (Camera_in.GetComponent<Camera>().enabled == true);
        Out_Enable = (Camera_out.GetComponent<Camera>().enabled == true);
        Sky_Enable = (Camera_sky.GetComponent<Camera>().enabled == true);
        Floor_Enable = (Camera_floor.GetComponent<Camera>().enabled == true);

        Out();
        In();
        Sky();
        Floor();
    }


    //Action-Rotate
    public void In()
    {
        if (In_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up") || Input.GetKey("down"))
            {
                Camera_in.transform.Rotate(vertical, 0, 0);
            }
            if (Input.GetKey("left") || Input.GetKey("right"))
            {
                Player.transform.Rotate(0, horizontal, 0);
            }
        }
    }

    //Action-Rotate
    public void Out()
    {
        if (Out_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up") || Input.GetKey("down"))
            {
                Camera_out.transform.Rotate(vertical, 0, 0);
            }
            if (Input.GetKey("left") || Input.GetKey("right"))
            {
                Player.transform.Rotate(0, horizontal, 0);
            }
        }
    }


    //Action-Rotate
    public void Sky()
    {
        if (Sky_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up") || Input.GetKey("down"))
            {
                Camera_sky.transform.Rotate(vertical, 0, 0);
            }
            if (Input.GetKey("left") || Input.GetKey("right"))
            {
                Player.transform.Rotate(0, horizontal, 0);
            }
        }
    }

    //Action-Rotate
    public void Floor()
    {
        if (Floor_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up") || Input.GetKey("down"))
            {
                Camera_floor.transform.Rotate(vertical, 0, 0);
            }
            if (Input.GetKey("left") || Input.GetKey("right"))
            {
                Player.transform.Rotate(0, horizontal, 0);
            }
        }
    }



}