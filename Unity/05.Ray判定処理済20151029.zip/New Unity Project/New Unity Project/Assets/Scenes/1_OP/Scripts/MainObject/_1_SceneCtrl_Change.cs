﻿using UnityEngine;
using System.Collections;

public class _1_SceneCtrl_Change : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
        Change();
    }

    public void Change()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("2_Start");
        }
    }

}