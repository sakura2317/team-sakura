﻿using UnityEngine;
using System.Collections;

public class _2_PlayerCtrl_Jump : MonoBehaviour
{
    private GameObject Player;

    void Start()
    {
        Player = GameObject.Find("/Player/");
    }

    void Update()
    {

    }

    //Action-Jump
    public void Jump()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            Player.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3);
            Debug.Log("じゃんぷ");
        }
    }
}