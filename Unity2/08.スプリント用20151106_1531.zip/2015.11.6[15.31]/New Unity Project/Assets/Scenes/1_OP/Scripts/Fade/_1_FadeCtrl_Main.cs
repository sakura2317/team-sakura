﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class _1_FadeCtrl_Main : MonoBehaviour
{
    private GameObject Obj_FedePanel;
    private Image Comp_FadePanel_Image;
    public Color Prop_Color;
    public int Int_Fade;//0:In_1:Out_2:SceneChange
    public float alpha;
    public float time;
    public float fadetime = 1f;
    public bool DontDestroyEnabled = true;

    void Start()
    {
        //━Fade━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_FedePanel = GameObject.Find("/_1_Fade/Canvas/FadePanel/");
        Comp_FadePanel_Image = Obj_FedePanel.GetComponent<Image>();
        Prop_Color = Comp_FadePanel_Image.color;
        //━Sceneを遷移してもオブジェクトが消えないようにする━━━━
        if (DontDestroyEnabled) { DontDestroyOnLoad(this); }
        //━Fadeの初期化━━━━━━━━━━━━━━━━━━━━━━━
        FadeIn_Initialize();
    }

    void Update()
    {
        FadeIn();
        FadeOut();
    }

    public void FadeIn()
    {
        if (Int_Fade == 0)
        {
            time += Time.deltaTime;
            alpha = (fadetime - time) / fadetime;
            Prop_Color.a = alpha;
            Comp_FadePanel_Image.color = Prop_Color;
        }
    }

    public void FadeOut()
    {
        if (Int_Fade == 1)
        {
            time += Time.deltaTime;
            alpha = time / fadetime;
            Prop_Color.a = alpha;
            Comp_FadePanel_Image.color = Prop_Color;
            if (alpha >= 1)
            {
                Int_Fade = 2;
            }
        }
    }

    //━FadeInの初期化━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeIn_Initialize()
    {
        Int_Fade = 0;
        time = 0;
        Prop_Color.a = 1;
    }

    //━FadeOutの初期化━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeOut_Initialize()
    {
        Int_Fade = 1;
        time = 0;
        Prop_Color.a = 0;
    }
}