﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_2_PlayerCtrl_Position))]
[RequireComponent(typeof(_2_PlayerCtrl_Jump))]
[RequireComponent(typeof(_2_PlayerCtrl_Target))]
[RequireComponent(typeof(_2_PlayerCtrl_SubTarget))]

public class _2_PlayerCtrl_Main : MonoBehaviour
{

	void Start ()
	{
		
	}
	

	void Update ()
	{
        GetComponent<_2_PlayerCtrl_Position>().InputTransA();
        GetComponent<_2_PlayerCtrl_Jump>().Jump();
        GetComponent<_2_PlayerCtrl_Target>().isTarget();
        GetComponent<_2_PlayerCtrl_SubTarget>().isTarget();
    }
}