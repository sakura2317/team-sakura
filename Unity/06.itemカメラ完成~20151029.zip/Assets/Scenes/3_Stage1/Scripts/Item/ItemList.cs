﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;
using System.Collections;

public class ItemList : MonoBehaviour {

	public GameObject mainCamera;
	//public EventSystem eventsystem;

	//ClickでRayをとばす
	public Ray ray;
	public Ray rayitem;
	public RaycastHit hit;
	public GameObject selectedGameObject;

	//アイテム
	private GameObject item_key1;
	private GameObject item_key2;
/*	private GameObject item_key3;
	private GameObject item_key4;
	private GameObject item_key5;
*/

	//item管理
	private string myitem;


	//アイテムボタン
	private GameObject itemBtn_key1;
	private GameObject itemBtn_key2;
/*	private GameObject itemBtn_key3;
	private GameObject itemBtn_key4;
	private GameObject itemBtn_key5;
*/
	// Use this for initialization
	void Start () {
		//eventsystem = GameObject.Find("EventSystem").GetComponent<EventSystem>();
		item_key1 = GameObject.Find ("item1");
		item_key2 = GameObject.Find ("item2");
/*		item_key3 = GameObject.Find ("item3");
		item_key4 = GameObject.Find ("item4");
		item_key5 = GameObject.Find ("item5");
*/
		GameObject.Find ("itemBtn_key_plane1").GetComponent<Renderer> ().enabled = false;
		GameObject.Find ("itemBtn_key_plane2").GetComponent<Renderer> ().enabled = false;
/*		GameObject.Find ("itemBtn_key_plane3").GetComponent<Renderer> ().enabled = false;
		GameObject.Find ("itemBtn_key_plane4").GetComponent<Renderer> ().enabled = false;
		GameObject.Find ("itemBtn_key_plane5").GetComponent<Renderer> ().enabled = false;
*/
		itemBtn_key1 = GameObject.Find ("itemBtn_key1");
		itemBtn_key2 = GameObject.Find ("itemBtn_key2");
/*		itemBtn_key3 = GameObject.Find ("itemBtn_key3");
		itemBtn_key4 = GameObject.Find ("itemBtn_key4");
		itemBtn_key5 = GameObject.Find ("itemBtn_key5");
*/
		itemBtn_key1.SetActive (false);
		itemBtn_key2.SetActive (false);
/*		itemBtn_key3.SetActive (false);
		itemBtn_key4.SetActive (false);
		itemBtn_key5.SetActive (false);
*/
		myitem = "noitem";
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonUp (0)) {
			searchitem();
		}
	}
	/*
	public void OnTriggerEnter(Collider c){
		if (c.gameObject.name == "item1") {
			item_key1.SetActive(false);
			itemBtn_key1.SetActive(true);
		}else if(c.gameObject.name == "item2") {
			item_key2.SetActive(false);
			itemBtn_key2.SetActive(true);

		}
	}
*/
	public void searchitem(){
		selectedGameObject = null;
		ray = Camera.main.ScreenPointToRay (Input.mousePosition);

		rayitem = GameObject.Find ("itemCamera").GetComponent<Camera> ().ScreenPointToRay (Input.mousePosition);
		if (Physics.Raycast (rayitem, out hit, 10000000, 1 << 12)) {
			selectedGameObject = hit.collider.gameObject;

			switch(selectedGameObject.name){
			case "itemBtn_key1":
				if(myitem == "item1"){
					GameObject.Find("itemBtn_key_plane1").GetComponent<Renderer>().enabled = false;
					myitem = "noitem";
				}else{
					GameObject.Find("itemBtn_key_plane1").GetComponent<Renderer>().enabled = true;
					myitem = "item1";
				}
				break;

			case "itemBtn_key2":
				if(myitem == "item2"){
					GameObject.Find("itemBtn_key_plane2").GetComponent<Renderer>().enabled = false;
					myitem = "noitem";
				}else{
					GameObject.Find("itemBtn_key_plane2").GetComponent<Renderer>().enabled = true;
					myitem = "item2";
				}
				break;

			}
			Debug.Log(myitem);
		}
	}
}
