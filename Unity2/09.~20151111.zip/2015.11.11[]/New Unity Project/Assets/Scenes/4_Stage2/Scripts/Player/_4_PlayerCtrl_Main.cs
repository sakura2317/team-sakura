﻿using UnityEngine;
using System.Collections;

public class _4_PlayerCtrl_Main : MonoBehaviour
{
    //━Player━━━━━━━━━━━━━━━
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.6f;  //Player移動スピード
    //━NextStagePoint━━━━━━━━━━
    public bool Bool_NextStagePoint_Search; //NextStagePointSearchチェック用
    public GameObject Obj_NextStagePoint;
    //━Item━━━━━━━━━━━━━━━━
    public bool Bool_Item_Search; //ItemSearchチェック用
    public GameObject Obj_Item;
    //━Ray━━━━━━━━━━━━━━━━
    private Camera Comp_Camera;
    private Ray Ray_mouse;
    private RaycastHit RaycastHit_Info;

    void Start()
    {
        //━NextStagePoint━━━━━━━━━━━━━━━━
        Obj_NextStagePoint = GameObject.Find("/Action/WrapPoint/");    //SetDestinationがあるためPlayerより先に記述！
        Bool_NextStagePoint_Search = false;
        //━Player━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //Comp_PlayerNMAgent.SetDestination((Vector3)Obj_NextStagePoint.transform.position);
        //━Item━━━━━━━━━━━━━━━━━━━━━━
        Obj_Item = GameObject.Find("/Item/");
        Obj_Item.SetActive(false);
        Bool_Item_Search = false;
        //━Ray━━━━━━━━━━━━━━━━━━━━━━━
        Comp_Camera = GameObject.Find("/Player/Camera_floor/").GetComponent<Camera>();
    }

    void Update()
    {
        Action_PositionTranslate_A();       //Playerの移動
        Action_Jump();                      //Playerのジャンプ
        AutoAction_NextStagePointSearch();  //NextStagePointの探索
        AutoAction_ItemSearch();            //Itemの探索
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0, 0, speed); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0, 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed, 0, 0); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0); }
    }
    public void Action_PositionTranslate_B()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up") || Input.GetKey("down")) { this.transform.Translate(0, 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_NextStagePointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_NextStagePointSearch()
    {
        if (Bool_NextStagePoint_Search == true && Bool_Item_Search == false)
        {
            Vector3 vec = (Vector3)Obj_NextStagePoint.transform.position;
            Comp_PlayerNMAgent.SetDestination(vec);
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_ItemSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_ItemSearch()
    {
        if (Input.GetMouseButtonUp(0) && Bool_NextStagePoint_Search == true)
        {
            //━Rayを作成(Mouse位置を原点とする)━━━
            Ray_mouse = Comp_Camera.ScreenPointToRay(Input.mousePosition);
            //━SceneViewでRayを表示━━━━━━━━
            Debug.DrawRay(Ray_mouse.origin, Ray_mouse.direction * 1000, Color.red, 0.1f);
            //━RayとColliderの衝突検出━━━━━━
            if (Physics.Raycast(Ray_mouse, out RaycastHit_Info, 10000000))   //(Physics.Raycast(原点の位置,方向,衝突情報,検知距離,レイヤーマスク))
            {
                if (RaycastHit_Info.collider.gameObject.name == "Floor")
                {
                    //Rayがhitした位置にItemを移動
                    Obj_Item.transform.position = RaycastHit_Info.point;
                    //Item表示
                    Obj_Item.SetActive(true);
                    Bool_Item_Search = true;
                    //NMAgent_SetDestination
                    Comp_PlayerNMAgent.SetDestination((Vector3)Obj_Item.transform.position);
                }
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}