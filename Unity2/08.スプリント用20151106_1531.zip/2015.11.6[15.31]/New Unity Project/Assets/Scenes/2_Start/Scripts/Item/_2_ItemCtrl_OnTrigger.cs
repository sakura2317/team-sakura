﻿using UnityEngine;
using System.Collections;

public class _2_ItemCtrl_OnTrigger : MonoBehaviour
{
    private _2_PlayerCtrl_Main PlayerCtrl;

    void Start()
    {
        PlayerCtrl = GameObject.Find("/Player/").GetComponent<_2_PlayerCtrl_Main>();
    }

    void Update()
    {

    }

    public void OnTriggerEnter(Collider other)
    {
        if (other == PlayerCtrl.Obj_Player.GetComponent<BoxCollider>())
        {
            PlayerCtrl.Obj_Item.SetActive(false);
            PlayerCtrl.Bool_Item_Search = false;
        }
    }

}