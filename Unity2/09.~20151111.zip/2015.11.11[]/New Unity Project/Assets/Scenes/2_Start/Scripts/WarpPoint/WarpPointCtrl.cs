﻿using UnityEngine;
using System.Collections;

public class WarpPointCtrl : MonoBehaviour
{
    //━FadeOut━━━━━━━━━━━━━━━
    private FadeCtrl FadeCtrl;
    //━Player━━━━━━━━━━━━━━━
    private _2_PlayerCtrl_Main PlayerCtrl;
    //━効果音━━━━━━━━━━━━━━━
    private AudioSource Comp_AudioSource;   // AudioSorceコンポーネント格納用
    public AudioClip sound;                 // 効果音の格納用。インスペクタで。

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EveryTime__[Obj_setActive==true && Comp_enabled==true]
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void OnEnable()
    {
        //━FadeOut━━━━━━━━━━━━━━━
        FadeCtrl = GameObject.Find("/UI/Fade/Panel/").GetComponent<FadeCtrl>();
        //━Player━━━━━━━━━━━━━━━
        PlayerCtrl = GameObject.Find("/Player/").GetComponent<_2_PlayerCtrl_Main>();
        //━効果音━━━━━━━━━━━━━━━
        Comp_AudioSource = gameObject.GetComponent<AudioSource>();
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // Trigger
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void OnTriggerEnter(Collider other)
    {
        //━FadeOut━━━━━━━━━━━━━━━
        FadeCtrl.FadeOut_Initialization();
        //━Player機能_Off━━━━━━━━━━━━━━━
        PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
        PlayerCtrl.Bool_NextStagePoint_Search = false;
        PlayerCtrl.Bool_Item_Search = false;
        //━効果音━━━━━━━━━━━━━━━
        Comp_AudioSource.PlayOneShot(sound);
    }
}