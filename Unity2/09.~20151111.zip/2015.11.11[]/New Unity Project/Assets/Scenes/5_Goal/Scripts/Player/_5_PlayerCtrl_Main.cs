﻿using UnityEngine;
using System.Collections;

public class _5_PlayerCtrl_Main : MonoBehaviour
{
    //━Player━━━━━━━━━━━━━━━
    public GameObject Obj_Player;
    public float speed = 0.2f;  //Player移動スピード
    //━BGM_Destroy━━━━━━━━━━━━
    private GameObject BGM;

    void Start(){
        //━PlayerObj━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        //━BGM_Destroy━━━━━━━━━━━━
        BGM = GameObject.Find("/Bgm/");
        Destroy(BGM);
    }

    void Update()
    {
        Action_PositionTranslate_A();   //Playerの移動
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0           , 0, speed       ); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0           , 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed       , 0, 0           ); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0           ); }
    }/*
    public void Action_PositionTranslate_B()
    {
        float vertical   = Input.GetAxis("Vertical"  );
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up"  ) || Input.GetKey("down" )) { this.transform.Translate(0                   , 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0                 ); }
    }*/
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}