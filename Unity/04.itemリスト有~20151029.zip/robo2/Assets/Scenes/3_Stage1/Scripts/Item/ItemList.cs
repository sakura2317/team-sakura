﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;
using System.Collections;

public class ItemList : MonoBehaviour {

	//public GameObject mainCamera;
	//public EventSystem eventsystem;

	//アイテム
	private GameObject item_key;

	//アイテムボタン
	private GameObject itemBtn_key;

	// Use this for initialization
	void Start () {
		//eventsystem = GameObject.Find("EventSystem").GetComponent<EventSystem>();
		item_key = GameObject.Find ("item");

		GameObject.Find ("itemBtn_key_plane").GetComponent<Renderer> ().enabled = false;
		itemBtn_key = GameObject.Find ("itemBtn_key");
		itemBtn_key.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void OnTriggerEnter(Collider c){
		if (c.gameObject.tag == "item") {
			item_key.SetActive(false);
			itemBtn_key.SetActive(true);
		}
	}
}
