﻿using UnityEngine;
using System.Collections;

public class _4_PlayerCtrl_Position : MonoBehaviour
{
    private GameObject PlayerObj;
    public float speed = 0.1f;

    void Start()
    {
        PlayerObj = GameObject.Find("/Player/");
    }

    void Update()
    {

    }

    //Action-Move
    public void InputTransA()
    {
        if (Input.GetKey(KeyCode.W)) { PlayerObj.transform.Translate(0, 0, speed); }
        if (Input.GetKey(KeyCode.S)) { PlayerObj.transform.Translate(0, 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { PlayerObj.transform.Translate(speed, 0, 0); }
        if (Input.GetKey(KeyCode.A)) { PlayerObj.transform.Translate(speed * (-1), 0, 0); }
    }

    //Action-Move
    public void InputTransB()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up") || Input.GetKey("down"))
        {
            PlayerObj.transform.Translate(0, 0, (vertical * speed));
        }
        if (Input.GetKey("left") || Input.GetKey("right"))
        {
            PlayerObj.transform.Translate((horizontal * speed), 0, 0);
        }
    }

}