﻿using UnityEngine;
using System.Collections;

public class _2_UICtrl_Main : MonoBehaviour
{
    private GameObject Obj_UI_Text;
    public Canvas Comp_UITextCanvas;
    public bool DontDestroyEnabled = true;

    void Start()
    {
        Obj_UI_Text = GameObject.Find("/_2_UI_Menu/Canvas/");
        Comp_UITextCanvas = Obj_UI_Text.GetComponent<Canvas>();
        Comp_UITextCanvas.enabled = true;
        //━Sceneを遷移してもオブジェクトが消えないようにする━━━━━━
        if (DontDestroyEnabled) { DontDestroyOnLoad(this); }
    }

    void Update()
    {
        Display();
    }

    public void Display()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (Comp_UITextCanvas.enabled == true) { Comp_UITextCanvas.enabled = false; }
            else if (Comp_UITextCanvas.enabled == false) { Comp_UITextCanvas.enabled = true; }
        }
    }
}