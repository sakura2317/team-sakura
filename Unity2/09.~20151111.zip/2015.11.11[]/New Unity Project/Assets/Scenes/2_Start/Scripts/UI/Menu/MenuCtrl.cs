﻿using UnityEngine;
using System.Collections;

public class MenuCtrl : MonoBehaviour
{
    public Canvas Comp_MenuCanvas;
    public int i;

    void Start()
    {
        Comp_MenuCanvas = GetComponent<Canvas>();
        //━メニューの初期化（表示・非表示）━━━━
        i = 0;  //0:false_1:true
        Comp_MenuCanvas.enabled = (i != 0);
    }

    void Update()
    {
        Display();
    }

    public void Display()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            if (i == 1)
            {
                Comp_MenuCanvas.enabled = false;
                i = 0;
            }
            else if (i == 0)
            {
                Comp_MenuCanvas.enabled = true;
                i = 1;
            }
        }
    }
}