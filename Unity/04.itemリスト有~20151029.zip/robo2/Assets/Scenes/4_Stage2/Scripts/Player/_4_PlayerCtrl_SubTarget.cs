﻿using UnityEngine;
using System.Collections;

public class _4_PlayerCtrl_SubTarget : MonoBehaviour
{
    private GameObject Player;
    private NavMeshAgent NMAgent;
    private GameObject Findtarget;
    private GameObject Savetarget;
	private GameObject PointMove;



    void Start()
    {
        Player = GameObject.Find("/Player");
        NMAgent = Player.GetComponent<NavMeshAgent>();
		Savetarget = GameObject.Find("Target");
		Savetarget.SetActive(false);
    }

    void Update()
    {

    }
    public void isTarget()
    {
		PointMove = GameObject.Find("/PointMove/");

		if (PointMove == null) {
			Findtarget = GameObject.Find ("Target");

			if (Findtarget != null) {
				Savetarget = GameObject.Find ("Target");
				Active_NMAComponent ();
				inActiveInputTrigger_TargetObj ();
			} else if (Findtarget == null) {
				ActiveInputTrigger_TargetObj ();
			}
		}
    }

    //inActive →　Active
    public void Active_NMAComponent()
    {
        Player.GetComponent<NavMeshAgent>().enabled = true;
        Findtarget = GameObject.Find("Target");
        NMAgent.SetDestination((Vector3)Findtarget.transform.position);   //destination=目的地
    }

    //Active →　inActive
    public void inActive_NMAComponent()
    {
        Player.GetComponent<NavMeshAgent>().enabled = false;
    }

    //TargetObj_Active →　inActive
    public void inActiveInputTrigger_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            Savetarget = GameObject.Find("Target");
            Savetarget.SetActive(false);
            inActive_NMAComponent();
        }
    }

    //TargetObj_inActive →　Active
    public void ActiveInputTrigger_TargetObj()
    {
        if (Input.GetKeyDown(KeyCode.O))
        {
            RandomPosition_TargetObj();
            Savetarget.SetActive(true);
            Active_NMAComponent();
        }
    }

    public void RandomPosition_TargetObj()
    {
        Savetarget.transform.position = new Vector3(Random.Range(-40, 40), 1f, Random.Range(-40, 40));
    }
}