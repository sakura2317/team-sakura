﻿using UnityEngine;
using System.Collections;

public class _5_TriggerPointCtrl_Main : MonoBehaviour
{
    private GameObject Obj_Player;
    private NavMeshAgent Comp_PlayerNMA;
    private GameObject Obj_TriggerPoint;
    private GameObject Obj_Door;
    private int Count = 0;
    private float timer;
    private float time1;
    private float time2;

    void Start()
    {
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMA = Obj_Player.GetComponent<NavMeshAgent>();
        Obj_TriggerPoint = GameObject.Find("/TriggerPoint/");
        Obj_Door = GameObject.Find("/Field-Wall/Door/");
    }

    void Update()
    {
        SceneChange();
        timer += Time.deltaTime;
        Debug.Log(timer);
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // SceneChangeCtrl
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void SceneChange()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("6_ED");
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // Action_DoorOpen & ChangeTriggerPoint
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>())
        {
            if (Count == 0)
            {
                //Playerの位置をTriggerPointと同期
                Vector3 pos = new Vector3(Obj_TriggerPoint.transform.position.x, 1.25f, Obj_TriggerPoint.transform.position.z);
                Obj_Player.transform.position = pos;
                Obj_Player.transform.rotation = Obj_TriggerPoint.transform.rotation;
                //NMA_false
                Comp_PlayerNMA.enabled = false;
                //Befor_OpenDoor
                if (Obj_Door.transform.position.y <= 11.5)
                {
                    Obj_Door.transform.Translate(0, 0.05f, 0);
                }
                //After_OpenDoor
                if (Obj_Door.transform.position.y >= 11.5)
                {
                    Obj_TriggerPoint.transform.position = new Vector3(0, 1.25f, 35);
                    Comp_PlayerNMA.enabled = true;
                    Comp_PlayerNMA.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
                    Count++;
                    time1 = timer;
                }
            }
            else if (Count == 1)
            {
                Comp_PlayerNMA.enabled = false;
                time2 = timer;
                if ((time2 - time1) > 6f)
                {
                    Comp_PlayerNMA.enabled = true;
                    Obj_TriggerPoint.transform.position = new Vector3(1.5f, 1.25f, 34.5f);
                    Comp_PlayerNMA.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
                    Count++;
                    time1 = timer;
                }
            }
            else if (Count == 2)
            {
                Comp_PlayerNMA.enabled = false;
                time2 = timer;
                if ((time2 - time1) > 2f)
                {
                    Comp_PlayerNMA.enabled = true;
                    Obj_TriggerPoint.transform.position = new Vector3(-1.5f, 1.25f, 34.5f);
                    Comp_PlayerNMA.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
                    Count++;
                    time1 = timer;
                }
            }
            else if (Count == 3)
            {
                Comp_PlayerNMA.enabled = false;
                time2 = timer;
                if ((time2 - time1) > 2f)
                {
                    Comp_PlayerNMA.enabled = true;
                    Obj_TriggerPoint.transform.position = new Vector3(-1.5f, 1.25f, 50);
                    Comp_PlayerNMA.SetDestination((Vector3)Obj_TriggerPoint.transform.position);
                    Count++;
                    time1 = timer;
                }
            }
            else {
                Comp_PlayerNMA.enabled = false;
                time2 = timer;
                if ((time2 - time1) > 10f)
                {
                    Application.LoadLevel("6_ED");
                }
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}