﻿using UnityEngine;
using System.Collections;

public class Spot_Trigger : MonoBehaviour {
    public GameObject Item_piece;
    private _3_PlayerCtrl_Main main;
    public GameObject Obj_Player;

    void Start () {
        Item_piece = GameObject.Find("Item_piece");
        Obj_Player = GameObject.Find("Player");
        main = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
    }

    // Update is called once per frame
    void Update () {
	
	}

    void OnTriggerEnter(Collider other)
    {
        if (other == Item_piece.GetComponent<CapsuleCollider>())
        {
            main.Bool_Item_Search = false;
            Debug.Log("false");
            Search();
        }
    }

    public void Search()
    {
        main.Obj_Item.SetActive(false);
        main.Comp_PlayerNMAgent.enabled = true;
        Vector3 vec = (Vector3)Item_piece.transform.position;
        main.Comp_PlayerNMAgent.SetDestination(vec);
    }
}
