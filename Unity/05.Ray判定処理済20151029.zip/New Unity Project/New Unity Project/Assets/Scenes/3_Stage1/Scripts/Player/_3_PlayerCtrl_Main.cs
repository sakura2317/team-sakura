﻿using UnityEngine;
using System.Collections;

public class _3_PlayerCtrl_Main : MonoBehaviour
{
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.5f;          //Player移動スピード
    public GameObject Obj_GoalPoint;    //リアルタイムnullチェック用
    public GameObject Obj_SaveGoalPoint;//表示非表示用
    public GameObject Obj_Item;         //リアルタイムnullチェック用
    public GameObject Obj_SaveItem;     //表示非表示用

    void Start(){
        //━PlayerObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //━WrapPointObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_SaveGoalPoint = GameObject.Find("/MovePoint/");
        Obj_GoalPoint = Obj_SaveGoalPoint;
        //━PlayerObj--Set_NMAComp_Destination━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveGoalPoint.transform.position);
        //━ItemObj━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_SaveItem = GameObject.Find("/Item/");
        Obj_SaveItem.SetActive(false);
        Obj_Item = null;
    }

    void Update()
    {
        Action_PositionTranslate_A();   //Playerの移動
        Action_Jump();                  //Playerのジャンプ
        AutoAction_GoalPointSearch();   //WrapPointの探索
        AutoAction_ItemSearch();        //Itemの探索
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0           , 0, speed       ); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0           , 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed       , 0, 0           ); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0           ); }
    }
    public void Action_PositionTranslate_B()
    {
        float vertical   = Input.GetAxis("Vertical"  );
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up"  ) || Input.GetKey("down" )) { this.transform.Translate(0                   , 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0                 ); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_GoalPointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_GoalPointSearch()
    {
        if (Obj_GoalPoint != null)  //isGoalPoint
        {
            if (Input.GetKeyDown(KeyCode.P))    //inActive_GoalPointObj
            {
                Obj_SaveGoalPoint.SetActive(false);
                Obj_GoalPoint = null;
                if (Obj_Item == null) { Comp_PlayerNMAgent.enabled = false; }
                if (Obj_Item != null) { Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveItem.transform.position); }
            }
        }
        else if (Obj_GoalPoint == null)  //isGoalPoint
        {
            if (Input.GetKeyDown(KeyCode.P))    //Active_GoalPointObj
            {
                Obj_SaveGoalPoint.SetActive(true);
                Obj_GoalPoint = Obj_SaveGoalPoint;
                if (Obj_Item == null)
                {
                    Comp_PlayerNMAgent.enabled = true;
                    Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveGoalPoint.transform.position);
                }
                //if (Obj_Item != null){そのままItem探索続行！}
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_ItemSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_ItemSearch()
    {
        if (Obj_Item != null)   //isItem
        {
            if (Input.GetKeyDown(KeyCode.O))    //inActive_ItemObj
            {
                Obj_SaveItem.SetActive(false);
                Obj_Item = null;
                if (Obj_GoalPoint == null) { Comp_PlayerNMAgent.enabled = false; }
                if (Obj_GoalPoint != null) { Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveGoalPoint.transform.position); }
            }
        }
        else if (Obj_Item == null)   //isItem
        {
            if (Input.GetKeyDown(KeyCode.O))    //inActive_ItemObj
            {
                RandomPosition_SaveItemObj();   //RandomPosition適応
                Obj_SaveItem.SetActive(true);
                Obj_Item = Obj_SaveItem;
                ////Obj_Item == null でも Obj_Item != null でも優先で探索
                Comp_PlayerNMAgent.enabled = true;
                Comp_PlayerNMAgent.SetDestination((Vector3)Obj_SaveItem.transform.position);
            }
        }
    }
    public void RandomPosition_SaveItemObj()
    {
        Obj_SaveItem.transform.position = new Vector3(Random.Range(-9, 9), 0.5f, Random.Range(-6, 3));
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}