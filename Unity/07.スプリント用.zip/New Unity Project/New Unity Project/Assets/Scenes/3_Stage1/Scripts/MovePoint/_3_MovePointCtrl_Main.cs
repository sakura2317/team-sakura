﻿using UnityEngine;
using System.Collections;

public class _3_MovePointCtrl_Main : MonoBehaviour
{
    private GameObject Obj_SearchPoint;
    private GameObject Obj_Player;
    private GameObject Obj_Door;
    private NavMeshAgent Comp_PlayerNMA;

    void Start()
    {
        Obj_SearchPoint = GameObject.Find("/MovePoint/");
        Obj_Player = GameObject.Find("/Player/");
        Obj_Door = GameObject.Find("/Field-Wall/Door/");

        Comp_PlayerNMA = Obj_Player.GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        SceneChange();
    }

    public void SceneChange()
    {
        if (Obj_SearchPoint.transform.position.z >= 50 || Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("4_Stage2");
        }
    }

    public void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>())
        {
            Comp_PlayerNMA.enabled = false;
            Player_ChangeRotate();
            MoveNextStage();
        }
    }

    public void Player_ChangeRotate()
    {
        Vector3 pos = new Vector3(Obj_SearchPoint.transform.position.x, 1.9f, Obj_SearchPoint.transform.position.z);
        Obj_Player.transform.position = pos;
        Obj_Player.transform.rotation = Obj_SearchPoint.transform.rotation;
    }

    public void MoveNextStage()
    {
        if (Obj_Door.transform.position.y <= 11.5)
        {
            Obj_Door.transform.Translate(0, 0.05f, 0);
        }
        if (Obj_Door.transform.position.y >= 11.5)
        {
            Obj_Player.transform.Translate(0, 0, Time.deltaTime);
            Obj_SearchPoint.transform.Translate(0, 0, Time.deltaTime);
        }
    }
}