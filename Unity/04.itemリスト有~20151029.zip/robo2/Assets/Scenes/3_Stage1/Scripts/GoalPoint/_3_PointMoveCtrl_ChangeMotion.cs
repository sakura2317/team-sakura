﻿using UnityEngine;
using System.Collections;

public class _3_PointMoveCtrl_ChangeMotion : MonoBehaviour
{
    private GameObject Point;
    private GameObject PointMove;
    private GameObject Player;
    private GameObject Door;

    void Start()
    {
        Point = GameObject.Find("/Point/");
        PointMove = GameObject.Find("/PointMove/");
        Player = GameObject.Find("/Player/");
        Door = GameObject.Find("/Field-Wall/Door/");
    }


    void Update()
    {

    }

    public void OnTriggerStay(Collider other)
    {
        if (other == Player.GetComponent<BoxCollider>())
        {
            inActive_GoalPoint();
            inActive_NMA();
            Player_ChangeRotate();
            MoveNextStage();
        }
    }

    public void Player_ChangeRotate()
    {
        Vector3 pos = new Vector3(PointMove.transform.position.x, 1.9f, PointMove.transform.position.z);
        Player.transform.position = pos;
        Player.transform.rotation = PointMove.transform.rotation;
    }

    public void MoveNextStage()
    {
        Player.transform.Translate(0, 0, Time.deltaTime);
        PointMove.transform.Translate(0, 0, Time.deltaTime);
        Door.transform.Translate(0, 0.05f, 0);
    }

    public void inActive_NMA()
    {
        Player.GetComponent<NavMeshAgent>().enabled = false;
    }

    public void inActive_GoalPoint()
    {
        Point.SetActive(false);
    }
    /*
	public IEnumerator Coroutines(){
		yield return new WaitForSeconds(1f);

	}
	*/
}
