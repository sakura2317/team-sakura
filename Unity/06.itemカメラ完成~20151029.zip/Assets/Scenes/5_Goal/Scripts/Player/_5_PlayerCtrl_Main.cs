﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_5_PlayerCtrl_Position))]
[RequireComponent(typeof(_5_PlayerCtrl_Jump))]
[RequireComponent(typeof(_5_PlayerCtrl_Target))]
[RequireComponent(typeof(_5_PlayerCtrl_SubTarget))]

public class _5_PlayerCtrl_Main : MonoBehaviour
{

	void Start ()
	{
		
	}
	

	void Update ()
	{
        GetComponent<_5_PlayerCtrl_Position>().InputTransA();
        GetComponent<_5_PlayerCtrl_Jump>().Jump();
        //GetComponent<_5_PlayerCtrl_Target>().isTarget();
        //GetComponent<_5_PlayerCtrl_SubTarget>().isTarget();
    }
}