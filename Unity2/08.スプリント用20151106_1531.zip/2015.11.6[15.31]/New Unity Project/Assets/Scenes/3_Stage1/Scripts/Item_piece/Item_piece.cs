﻿using UnityEngine;
using System.Collections;

public class Item_piece : MonoBehaviour
{
    public GameObject[] door1;
    public GameObject Obj_Player;
    public bool open = false;
    float f = 0;
    private _3_PlayerCtrl_Main main;

    void Start()
    {
        door1 = GameObject.FindGameObjectsWithTag("Door1");
        Obj_Player = GameObject.Find("Player");
        main = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
    }

    void Update()
    {
        DoorOpen();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>())
        {
            open = true;
            this.transform.position = new Vector3(0,10,0);
            main.Bool_Item_Search = true;
            Debug.Log("true");
            Debug.Log(open);
        }
    }

    public void DoorOpen()
    {
        if (open == true)
        {
            for (int i = 0; i < 4; i++)
            {
                f += 0.3f;
                door1[i].transform.Translate(-0.3f, 0, 0);
                main.Comp_PlayerNMAgent.enabled = false;
            }
            if (f >= 28f) {
                open = false;
            }
        }
    }

}
