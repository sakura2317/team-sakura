﻿using UnityEngine;
using System.Collections;

public class Item_piece : MonoBehaviour {
    private _3_PlayerCtrl_Main PlayerCtrl;
    public GameObject Obj_Player;
    public GameObject Obj_PlayerPlayer;
    public GameObject Obj_PlayerSpot;

    void Start () {
        Obj_Player = GameObject.Find("Player");
        Obj_PlayerPlayer = GameObject.Find("Player/Playerr");
        Obj_PlayerSpot = GameObject.Find("Player/Spot");
        PlayerCtrl = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
        Debug.Log(Obj_Player);
        Debug.Log(Obj_PlayerPlayer);
        Debug.Log(Obj_PlayerSpot);
    }

    void Update () {
	
	}

    void OnTriggerEnter(Collider other){
        if (other == Obj_PlayerSpot.GetComponent<CapsuleCollider>())
        {
            Debug.Log("Search-On");
            Debug.Log(PlayerCtrl);
            PlayerCtrl.Bool_Item_Search = false;
            //━Search━━━━━━━━━━━━━━━━━━━
            PlayerCtrl.Obj_Item.SetActive(false);
            PlayerCtrl.Comp_PlayerNMAgent.enabled = true;
            Vector3 vec = (Vector3)transform.position;
            PlayerCtrl.Comp_PlayerNMAgent.SetDestination(vec);
        }
        else if (other == Obj_PlayerPlayer.GetComponent<CapsuleCollider>())
        {
            Debug.Log("Item-Get");
            Debug.Log(gameObject);
            PlayerCtrl.Bool_SE_Item_piece = true;
            Destroy(gameObject);
            PlayerCtrl.Count++;
            PlayerCtrl.Text.text = "Item: " + PlayerCtrl.Count;
            PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
            PlayerCtrl.Bool_Item_Search = true;
        }

    }
}
