﻿using UnityEngine;
using System.Collections;

public class _5_CameraCtrl_Main : MonoBehaviour
{
    private GameObject Obj_Camera_in;
    private GameObject Obj_Camera_out;
    private GameObject Obj_Camera_floor;
    private GameObject Obj_Camera_mini;
    public Camera Comp_CameraIn;
    public Camera Comp_CameraOut;
    public Camera Comp_CameraFloor;
    public Camera Comp_CameraMini;
    private bool In_Enable;
    private bool Out_Enable;
    private bool Floor_Enable;
    private bool Mini_Enable;
    private float RotateSpeed = 3.0f;


    void Start()
    {
        //━Object取得━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Camera_in = GameObject.Find("/Player/Player_Camera_in/");
        Obj_Camera_out = GameObject.Find("/Player/Player_Camera_out/");
        Obj_Camera_floor = GameObject.Find("/Player/Camera_floor/");
        Obj_Camera_mini = GameObject.Find("/MainObject/Camera_mini/");
        //━カメラComponent取得━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_CameraIn = Obj_Camera_in.GetComponent<Camera>();
        Comp_CameraOut = Obj_Camera_out.GetComponent<Camera>();
        Comp_CameraFloor = Obj_Camera_floor.GetComponent<Camera>();
        Comp_CameraMini = Obj_Camera_mini.GetComponent<Camera>();
        //━初期カメラ設定━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_CameraIn.enabled = false;
        Comp_CameraOut.enabled = true;
        Comp_CameraFloor.enabled = false;
        Comp_CameraMini.enabled = false;
    }

    void Update()
    {
        //━各CameraのOn-Offチェック━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        In_Enable = (Comp_CameraIn.enabled == true);
        Out_Enable = (Comp_CameraOut.enabled == true);
        Floor_Enable = (Comp_CameraFloor.enabled == true);
        Mini_Enable = (Comp_CameraMini.enabled == true);
        //━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Change();   //カメラ切り替え
        Rotate();   //カメラ回転
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // CameraCtrl_Change
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Change()
    {
        //━InCamera_Change━━━━━━━━━━━
        if (Input.GetKeyDown(KeyCode.I))
        {
            if (In_Enable == false)
            {
                Comp_CameraIn.enabled = true;
                Comp_CameraOut.enabled = false;
                Comp_CameraFloor.enabled = false;
            }
            if (In_Enable == true)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = false;
                Comp_CameraFloor.enabled = true;
            }
        }
        //━OutCamera_Change━━━━━━━━━━━
        else if (Input.GetKeyDown(KeyCode.O))
        {
            if (Out_Enable == false)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = true;
                Comp_CameraFloor.enabled = false;
            }
            if (Out_Enable == true)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = false;
                Comp_CameraFloor.enabled = true;
            }
        }
        //━FloorCamera_Change━━━━━━━━━━━
        else if (Input.GetKeyDown(KeyCode.U))
        {
            Comp_CameraIn.enabled = false;
            Comp_CameraOut.enabled = false;
            Comp_CameraFloor.enabled = true;
        }
        //━MiniCamera_On-Off━━━━━━━━━━━
        else if (Input.GetKeyDown(KeyCode.P))
        {
            if (Mini_Enable == false) { Comp_CameraMini.enabled = true; }
            if (Mini_Enable == true) { Comp_CameraMini.enabled = false; }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // CameraCtrl_Rotate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Rotate()
    {
        //━InCamera_Rotate━━━━━━━━━━━━━━━━━━━━━━
        if (In_Enable == true)
        {
            //━ｷｰﾎﾞｰﾄﾞ入力━
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");
            //━回転━━━━
            if (Input.GetKey("up") || Input.GetKey("down")) { Obj_Camera_in.transform.Rotate(vertical * RotateSpeed, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Camera_in.transform.Rotate(0, horizontal * RotateSpeed, 0); }
        }
        //━OutCamera_Rotate━━━━━━━━━━━━━━━━━━━━━
        else if (Out_Enable == true)
        {
            //━ｷｰﾎﾞｰﾄﾞ入力━
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");
            //━回転━━━━
            if (Input.GetKey("up") || Input.GetKey("down")) { Obj_Camera_out.transform.Rotate(vertical * RotateSpeed, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Camera_out.transform.Rotate(0, horizontal * RotateSpeed, 0); }
        }
        //━FloorCamera_Rotate━━━━━━━━━━━━━━━━━━━━━
        else if (Floor_Enable == true)
        {
            //━ｷｰﾎﾞｰﾄﾞ入力━
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");
            //━回転━━━━
            if (Input.GetKey("up") || Input.GetKey("down")) { Obj_Camera_floor.transform.Rotate(vertical * RotateSpeed, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Camera_floor.transform.Rotate(0, horizontal * RotateSpeed, 0); }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}
