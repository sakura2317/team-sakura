﻿using UnityEngine;
using System.Collections;

public class _4_SceneCtrl_Change : MonoBehaviour
{
    private _1_FadeCtrl_Main FadeCtrl;
    private _4_PlayerCtrl_Main PlayerCtrl;
    private AudioSource audioSource;    // AudioSorceコンポーネント格納用
    public AudioClip sound;        // 効果音の格納用。インスペクタで。

    void Start ()
	{
        FadeCtrl = GameObject.Find("/_1_Fade/").GetComponent<_1_FadeCtrl_Main>();
        PlayerCtrl = GameObject.Find("/Player/").GetComponent<_4_PlayerCtrl_Main>();
        audioSource = gameObject.GetComponent<AudioSource>();
    }

    void Update() {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("5_Goal");
        }
    }

	public void OnTriggerEnter(Collider other)
    {
        FadeCtrl.FadeOut_Initialize();
        PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
        PlayerCtrl.Bool_NextStagePoint_Search = false;
        audioSource.PlayOneShot(sound);
    }

    public void OnTriggerStay(Collider other)
    {
        if (FadeCtrl.Int_Fade == 2)
        {
            Application.LoadLevel("5_Goal");
        }
    }

}