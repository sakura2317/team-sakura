﻿using UnityEngine;
using System.Collections;

public class Locker : MonoBehaviour {
    public GameObject Obj_Player;

    // Use this for initialization
    void Start () {
        Obj_Player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update () {
	
	}

    void OnTriggerStay(Collider other)
    {
        if (other == Obj_Player.GetComponent<BoxCollider>())
        {
            this.transform.Translate(0, -0.1f,0);
        }
    }
}
