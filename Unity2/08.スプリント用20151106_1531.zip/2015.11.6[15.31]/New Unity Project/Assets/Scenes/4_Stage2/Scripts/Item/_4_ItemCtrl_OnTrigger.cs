﻿using UnityEngine;
using System.Collections;

public class _4_ItemCtrl_OnTrigger : MonoBehaviour
{
    private GameObject Obj_Player;
    private _4_PlayerCtrl_Main main;

    void Start()
    {
        Obj_Player = GameObject.Find("/Player/");
        main = Obj_Player.GetComponent<_4_PlayerCtrl_Main>();
    }

    void Update()
    {

    }

    public void OnTriggerEnter(Collider other)
    {
        if (other == main.Obj_Player.GetComponent<BoxCollider>())
        {
            main.Obj_Item.SetActive(false);
            main.Bool_Item_Search = false;
        }
    }

}