﻿using UnityEngine;
using System.Collections;

public class _2_PlayerCtrl_Main : MonoBehaviour
{
    //━Player━━━━━━━━━━━━━━━
    public GameObject Obj_Player;
    public NavMeshAgent Comp_PlayerNMAgent;
    public float speed = 0.2f;  //Player移動スピード
    //━NextStagePoint━━━━━━━━━━
    public bool Bool_NextStagePoint_Search; //NextStagePointSearchチェック用
    public GameObject Obj_NextStagePoint;
    //━Item━━━━━━━━━━━━━━━━
    public bool Bool_Item_Search; //ItemSearchチェック用
    public GameObject Obj_Item;
    //━Ray━━━━━━━━━━━━━━━━
    private Camera Comp_Camera;
    private Ray Ray_mouse;
    private RaycastHit RaycastHit_Info;

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EveryTime__[Obj_setActive==true && Comp_enabled==true]
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void OnEnable()
    {
        //━Player━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Comp_PlayerNMAgent = Obj_Player.GetComponent<NavMeshAgent>();
        //━NextStagePoint━━━━━━━━━━━━━━━━
        Obj_NextStagePoint = GameObject.Find("/WrapPoint/");    //SetDestinationがあるためPlayerより先に記述！
        Bool_NextStagePoint_Search = false;
        Comp_PlayerNMAgent.enabled = true;
        //Comp_PlayerNMAgent.SetDestination((Vector3)Obj_NextStagePoint.transform.position);
        //━Item━━━━━━━━━━━━━━━━━━━━━━
        Obj_Item = GameObject.Find("/Item/");
        Obj_Item.SetActive(false);
        Bool_Item_Search = true;
        //━Ray━━━━━━━━━━━━━━━━━━━━━━━
        Comp_Camera = GameObject.Find("/MainObject/Camera_floor/").GetComponent<Camera>();
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // Update
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void Update()
    {
        Action_PositionTranslate_A();       //Playerの移動
        //Action_Jump();                      //Playerのジャンプ
        AutoAction_NextStagePointSearch();  //NextStagePointの探索
        AutoAction_ItemSearch();            //Itemの探索
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_PositionTranslate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_PositionTranslate_A()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0, 0, speed); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0, 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed, 0, 0); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0); }
    }/*
    public void Action_PositionTranslate_B()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        if (Input.GetKey("up") || Input.GetKey("down")) { this.transform.Translate(0, 0, (vertical * speed)); }
        if (Input.GetKey("left") || Input.GetKey("right")) { this.transform.Translate((horizontal * speed), 0, 0); }
    }*/
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_Action_Jump
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Action_Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space)) { this.GetComponent<Rigidbody>().AddForce(Vector3.up * (1000) * 3); }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_GoalPointSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_NextStagePointSearch()
    {
        if (Bool_NextStagePoint_Search != true) { return; }
            Vector3 vec = (Vector3)Obj_NextStagePoint.transform.position;
            Comp_PlayerNMAgent.SetDestination(vec);
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // PlayerCtrl_AutoAction_ItemSearch
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void AutoAction_ItemSearch()
    {
        if(Bool_Item_Search != true) { return; }
            if (Input.GetMouseButtonUp(0) != true) { return; }
                Bool_NextStagePoint_Search = false;
                //━Rayを作成(Mouse位置を原点とする)━━━
                Ray_mouse = Comp_Camera.ScreenPointToRay(Input.mousePosition);
                Debug.DrawRay(Ray_mouse.origin, Ray_mouse.direction * 1000, Color.red, 0.1f);//SceneViewでRayを表示
                //━RayとColliderの衝突検出━━━━━━━━
                Physics.Raycast(Ray_mouse, out RaycastHit_Info, 10000000);
                if (RaycastHit_Info.collider.gameObject.name != "Floor") { return; }
                    //━Rayがhitした位置にItemを移動・表示━━━━━
                    Obj_Item.transform.position = RaycastHit_Info.point;
                    Obj_Item.SetActive(true);
                    //━NMAgent_SetDestination━━━━━━━━
                    Comp_PlayerNMAgent.SetDestination((Vector3)Obj_Item.transform.position);
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EveryTime__[Obj_Create(Instantinate)]
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ////void Awake() { Debug.Log("Player_Awake()"); }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // OneTime__[Obj_Create(Instantinate) && Comp_enabled==true]
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ////void Start(){ Debug.Log("Player_Start()"); }
}