﻿using UnityEngine;
using System.Collections;

public class _5_UICtrl_Main : MonoBehaviour
{
    private GameObject Obj_Menu;
    private Canvas Comp_MenuCanvas;

    void Start()
    {
        Obj_Menu = GameObject.Find("/UI/Menu/");
        Comp_MenuCanvas = Obj_Menu.GetComponent<Canvas>();
        //初期値設定＿非表示
        Comp_MenuCanvas.enabled = false;
    }

    void Update()
    {

    }
}