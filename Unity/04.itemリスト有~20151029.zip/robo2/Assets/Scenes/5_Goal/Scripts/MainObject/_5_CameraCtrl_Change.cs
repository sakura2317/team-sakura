﻿using UnityEngine;
using System.Collections;

public class _5_CameraCtrl_Change : MonoBehaviour
{
    private GameObject Camera_in;
    private GameObject Camera_out;
    private GameObject Camera_sky;
    private bool In_Enable;
    private bool Out_Enable;
    private bool Sky_Enable;

    void Start()
    {
        Camera_in = GameObject.Find("/Player/Player_Camera_in");
        Camera_out = GameObject.Find("/Player/Player_Camera_out");
        Camera_sky = GameObject.Find("/MainObject/Camera/Camera_sky");

        Camera_in.GetComponent<Camera>().enabled = true;
        Camera_out.GetComponent<Camera>().enabled = false;
        Camera_sky.GetComponent<Camera>().enabled = false;
    }

    void Update()
    {

    }

    public void Change()
    {
        In_Enable = (Camera_in.GetComponent<Camera>().enabled == true);
        Out_Enable = (Camera_out.GetComponent<Camera>().enabled == true);
        Sky_Enable = (Camera_sky.GetComponent<Camera>().enabled == true);

        In_Out();
        Sky();

        /*
        Debug.Log("In  : " + In_Enable);
        Debug.Log("Out : " + Out_Enable);
        Debug.Log("Sky : " + Sky_Enable);
        */
    }

    public void In_Out()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (In_Enable == true && Out_Enable == false && Sky_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
            }

            if (In_Enable == false && Out_Enable == true && Sky_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = true;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = false;
            }

            if (In_Enable == false && Out_Enable == false && Sky_Enable == true)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
            }
        }
    }

    public void Sky()
    {
        if (Input.GetKeyDown(KeyCode.V))
        {
            if ((In_Enable == true || Out_Enable == true) && Sky_Enable == false)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = false;
                Camera_sky.GetComponent<Camera>().enabled = true;
            }

            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == true)
            {
                Camera_in.GetComponent<Camera>().enabled = false;
                Camera_out.GetComponent<Camera>().enabled = true;
                Camera_sky.GetComponent<Camera>().enabled = false;
            }
        }
    }

}