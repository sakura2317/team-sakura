﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_2_CameraCtrl_Change))]
[RequireComponent(typeof(_2_CameraCtrl_Rotate))]
[RequireComponent(typeof(_2_UICtrl_Active))]

public class _2_MainCtrl : MonoBehaviour
{
	public GameObject WarpPoint;

	void Start ()
	{
        Physics.gravity = new Vector3(0, -8f, 0);
        WarpPoint = GameObject.Find ("WrapPoint");
	}
	
	void Update ()
	{
        GetComponent<_2_CameraCtrl_Change>().Change();
        GetComponent<_2_CameraCtrl_Rotate>().Rotate();
        GetComponent<_2_UICtrl_Active>().Display();

        WarpPoint.GetComponent<_2_SceneCtrl_Change>().Change();

    }
}