﻿using UnityEngine;
using System.Collections;

public class _3_SceneCtrl_Change : MonoBehaviour
{
    private GameObject PointMove;

    void Start ()
	{
        PointMove = GameObject.Find("PointMove");
    }

    // Update is called once per frame
    void Update ()
	{
		
	}

    public void Change()
    {
        if (PointMove.transform.position.z >= 60 || Input.GetKeyDown(KeyCode.Return))
        {
            Application.LoadLevel("4_Stage2");
        }
    }
}