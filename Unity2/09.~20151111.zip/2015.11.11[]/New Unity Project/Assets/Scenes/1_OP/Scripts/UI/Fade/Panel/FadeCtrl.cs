﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FadeCtrl : MonoBehaviour
{
    //━FadePanel_Color━━━━━━━━━━━━━━━━
    public Image Comp_FadePanelImage;
    public Color col;
    public int Phase;//0:In_1:Out_2:SceneChange
    public float timer;
    public float fadetime = 1f;
    //━SceneCtrl━━━━━━━━━━━━━━━━━━━━
    public string SceneName;

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // EveryTime__[Obj_setActive==true && Comp_enabled==true]
    // オブジェクト作成後の初期化
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void OnEnable()
    {
        //━FadePanel_Color━━━━━━━━━━━━━━━━━
        Comp_FadePanelImage = GetComponent<Image>();
        col = Comp_FadePanelImage.color;
        FadeIn_Initialization();
        SceneName = GameObject.Find("/UI/Scene/Text/").GetComponent<Text>().text;
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    void Update()
    {
        FadeIn();
        FadeOut();
        SceneChange();
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // FadeInの初期化
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeIn_Initialization()
    {
        Phase = 0;
        timer = 0;
        col.a = 1;
        Comp_FadePanelImage.color = col;

    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // FadeInの実行
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeIn()
    {
        if (Phase != 0) { return; }
        timer += Time.deltaTime;
        col.a = (fadetime - timer) / fadetime;
        Comp_FadePanelImage.color = col;
        if (Input.GetKeyDown(KeyCode.Return)) { FadeOut_Initialization(); } //★
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // FadeOutの初期化
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeOut_Initialization()
    {
        Phase = 1;
        timer = 0;
        col.a = 0;
        Comp_FadePanelImage.color = col;
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // FadeOutの実行
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void FadeOut()
    {
        if (Phase != 1) { return; }
        timer += Time.deltaTime;
        col.a = timer / fadetime;
        Comp_FadePanelImage.color = col;
        if (col.a >= 1) { Phase = 2; }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // SceneChange
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void SceneChange()
    {
        if (Phase != 2) { return; }
        if (SceneName.Contains("OP"))
        {
            Application.LoadLevel("2_Start");
        }
        else if (SceneName.Contains("Start"))
        {
            Application.LoadLevel("3_Stage1");
        }
        else if (SceneName.Contains("Stage1"))
        {
            Application.LoadLevel("4_Stage2");
        }
        else if (SceneName.Contains("Stage2"))
        {
            Application.LoadLevel("5_Goal");
        }
        else if (SceneName.Contains("Goal"))
        {
            Application.LoadLevel("6_ED");
        }
    }
}