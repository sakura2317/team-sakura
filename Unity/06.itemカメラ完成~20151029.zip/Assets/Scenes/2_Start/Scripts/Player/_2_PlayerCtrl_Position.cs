﻿using UnityEngine;
using System.Collections;

public class _2_PlayerCtrl_Position : MonoBehaviour
{
    private GameObject Player;
    public float speed = 0.2f;

    void Start()
    {
        Player = GameObject.Find("/Player/");
    }

    void Update()
    {

    }

    //Action-Move
    public void InputTransA()
    {
        if (Input.GetKey(KeyCode.W)) { this.transform.Translate(0, 0, speed); }
        if (Input.GetKey(KeyCode.S)) { this.transform.Translate(0, 0, speed * (-1)); }
        if (Input.GetKey(KeyCode.D)) { this.transform.Translate(speed, 0, 0); }
        if (Input.GetKey(KeyCode.A)) { this.transform.Translate(speed * (-1), 0, 0); }
    }

    //Action-Move
    public void InputTransB()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");

        if (Input.GetKey("up") || Input.GetKey("down"))
        {
            Player.transform.Translate(0, 0, (vertical * speed));
        }
        if (Input.GetKey("left") || Input.GetKey("right"))
        {
            Player.transform.Translate((horizontal * speed), 0, 0);
        }
    }

}