﻿using UnityEngine;
using System.Collections;

public class _5_UICtrl_Main : MonoBehaviour
{
    private GameObject Obj_UI_Text;
    private Canvas Comp_UITextCanvas;

    void Start()
    {
        Obj_UI_Text = GameObject.Find("/_2_UI_Menu/Canvas/");
        Comp_UITextCanvas = Obj_UI_Text.GetComponent<Canvas>();
        //初期値設定＿非表示
        Comp_UITextCanvas.enabled = false;
    }

    void Update()
    {

    }
}