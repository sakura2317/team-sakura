﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_4_PlayerCtrl_Position))]
[RequireComponent(typeof(_4_PlayerCtrl_Jump))]
[RequireComponent(typeof(_4_PlayerCtrl_Target))]
[RequireComponent(typeof(_4_PlayerCtrl_SubTarget))]

public class _4_PlayerCtrl_Main : MonoBehaviour
{

    void Start ()
	{
		
	}
	
	// Update is called once per frame
	void Update ()
	{
        GetComponent<_4_PlayerCtrl_Position>().InputTransA();
        GetComponent<_4_PlayerCtrl_Jump>().Jump();
        GetComponent<_4_PlayerCtrl_Target>().isTarget();
        GetComponent<_4_PlayerCtrl_SubTarget>().isTarget();

    }
}