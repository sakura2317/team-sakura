﻿using UnityEngine;
using System.Collections;

public class _4_PlayerCtrl_Jump : MonoBehaviour
{
    private GameObject PlayerObj;

    void Start()
    {
        PlayerObj = GameObject.Find("/Player");
    }

    void Update()
    {

    }

    //Action-Jump
    public void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            PlayerObj.GetComponent<Rigidbody>().AddForce(Vector3.up * 1000 * 3);
        }
    }
}