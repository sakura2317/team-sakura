﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(_5_CameraCtrl_Change))]
[RequireComponent(typeof(_5_CameraCtrl_Rotate))]
[RequireComponent(typeof(_5_UICtrl_Active))]

public class _5_MainCtrl : MonoBehaviour
{
	public GameObject WarpPoint;

	void Start ()
	{
        Physics.gravity = new Vector3(0, -8f, 0);
        WarpPoint = GameObject.Find ("WrapPoint");
	}
	
	void Update ()
	{
        GetComponent<_5_CameraCtrl_Change>().Change();
        GetComponent<_5_CameraCtrl_Rotate>().Rotate();
        GetComponent<_5_UICtrl_Active>().Display();

        //WarpPoint.GetComponent<_5_SceneCtrl_Change>().Change();

    }
}