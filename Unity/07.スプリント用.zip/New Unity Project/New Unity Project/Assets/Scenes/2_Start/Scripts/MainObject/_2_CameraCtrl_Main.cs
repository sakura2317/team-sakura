﻿using UnityEngine;
using System.Collections;

public class _2_CameraCtrl_Main : MonoBehaviour
{
    private GameObject Obj_Player;
    private GameObject Obj_Camera_in;
    private GameObject Obj_Camera_out;
    private GameObject Obj_Camera_sky;
    private Camera Comp_CameraIn;
    private Camera Comp_CameraOut;
    private Camera Comp_CameraSky;
    private bool In_Enable;
    private bool Out_Enable;
    private bool Sky_Enable;

    void Start ()
	{
        //━Object取得━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Obj_Player = GameObject.Find("/Player/");
        Obj_Camera_in = GameObject.Find("/Player/Player_Camera_in/");
        Obj_Camera_out = GameObject.Find("/Player/Player_Camera_out/");
        Obj_Camera_sky = GameObject.Find("/MainObject/Camera_sky/");
        //━カメラComponent取得━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_CameraIn = Obj_Camera_in.GetComponent<Camera>();
        Comp_CameraOut = Obj_Camera_out.GetComponent<Camera>();
        Comp_CameraSky = Obj_Camera_sky.GetComponent<Camera>();
        //━初期カメラ設定━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        Comp_CameraIn.enabled = false;
        Comp_CameraOut.enabled = false;
        Comp_CameraSky.enabled = true;
    }

    void Update ()
	{
        In_Enable = (Comp_CameraIn.enabled == true);
        Out_Enable = (Comp_CameraOut.enabled == true);
        Sky_Enable = (Comp_CameraSky.enabled == true);

        Change();
        Rotate();
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // CameraCtrl_Change
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Change()
    {
        In_Out();
        Sky();
    }
    public void In_Out()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (In_Enable == true && Out_Enable == false && Sky_Enable == false)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = true;
                Comp_CameraSky.enabled = false;
            }

            if (In_Enable == false && Out_Enable == true && Sky_Enable == false)
            {
                Comp_CameraIn.enabled = true;
                Comp_CameraOut.enabled = false;
                Comp_CameraSky.enabled = false;
            }

            if (In_Enable == false && Out_Enable == false && Sky_Enable == true)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = true;
                Comp_CameraSky.enabled = false;
            }
        }
    }
    public void Sky()
    {
        if (Input.GetKeyDown(KeyCode.V))
        {
            if ((In_Enable == true || Out_Enable == true) && Sky_Enable == false)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = false;
                Comp_CameraSky.enabled = true;
            }

            else if ((In_Enable == false && Out_Enable == false) && Sky_Enable == true)
            {
                Comp_CameraIn.enabled = false;
                Comp_CameraOut.enabled = true;
                Comp_CameraSky.enabled = false;
            }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // CameraCtrl_Rotate
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    public void Rotate()
    {
        Action_RotateCameraIn();
        Action_RotateCameraOut();
        Action_RotateCameraSky();
    }
    public void Action_RotateCameraIn()
    {
        if (In_Enable == true)
        {
            float vertical   = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up"  ) || Input.GetKey("down" )) { Obj_Camera_in.transform.Rotate(vertical, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Player.transform.Rotate(0, horizontal, 0); }
        }
    }
    public void Action_RotateCameraOut()
    {
        if (Out_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up"  ) || Input.GetKey("down" )) { Obj_Camera_out.transform.Rotate(vertical, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Player.transform.Rotate(0, horizontal, 0); }
        }
    }
    public void Action_RotateCameraSky()
    {
        if (Sky_Enable == true)
        {
            float vertical = (-1) * Input.GetAxis("Vertical");
            float horizontal = Input.GetAxis("Horizontal");

            if (Input.GetKey("up") || Input.GetKey("down")){ Obj_Camera_sky.transform.Rotate(vertical, 0, 0); }
            if (Input.GetKey("left") || Input.GetKey("right")) { Obj_Player.transform.Rotate(0, horizontal, 0); }
        }
    }
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
}