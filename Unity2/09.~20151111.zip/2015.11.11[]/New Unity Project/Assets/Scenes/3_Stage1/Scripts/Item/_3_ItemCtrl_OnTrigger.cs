﻿using UnityEngine;
using System.Collections;

public class _3_ItemCtrl_OnTrigger : MonoBehaviour
{
    private GameObject Obj_Player;
    private _3_PlayerCtrl_Main PlayerCtrl;

    void OnEnable()
    {
        Obj_Player = GameObject.Find("/Player/");
        PlayerCtrl = Obj_Player.GetComponent<_3_PlayerCtrl_Main>();
        //━効果音━━━━━━━━━━━━━━━
    }

    void Update()
    {

    }

    public void OnTriggerEnter(Collider other)
    {
        if (other == PlayerCtrl.Obj_Player.GetComponent<BoxCollider>())
        {
            //━━━━━━━━━━━━━━━━━━━
            PlayerCtrl.Bool_SE_Item = true;
            PlayerCtrl.Obj_Item.SetActive(false);
            PlayerCtrl.Comp_PlayerNMAgent.enabled = false;
        }
    }

}